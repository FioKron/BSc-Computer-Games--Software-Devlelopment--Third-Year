<?php
	$db = mysqli_connect('localhost', 'id3118701_theakashictraveller', '2DShooterPassword') or die('Could not connect: '.mysqli_error($db));
	mysqli_select_db($db, 'id3118701_2dshooter') or die('Could not select database');
	
	$username = mysql_real_escape_string($_GET['name'], &db);
	$score = mysql_real_escape_string($_GET['score'], $db);
	$hash = $_GET['hash'];
	$privateKey="ISqvXa9ZSZ";
	
	$expected_hash = md5($username . $score . $privateKey);
	if($expectedHash == $hash) {
		$query = "INSERT INTO highscores
		SET name = '$name'
		, score = '$score'
		, ts = CURRENT_TIMESTAMPT
		
		ON DUPLICATE KEY UPDATE
			ts = if('$score'>score,CURRENT_TIMESTAMPT,ts), score = if ('$score'>score, '$score', score);
		";
		
		$result = mysql_query($query) or die('Query failed: ' . mysql_error());
	}
?>
			
	}