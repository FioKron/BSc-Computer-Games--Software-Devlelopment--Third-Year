<?php
	$db = mysqli_connect('localhost', 'id3118701_theakashictraveller', '2DShooterPassword') or die('Could not connect: '.mysqli_error($db));
	mysqli_select_db($db, 'id3118701_2dshooter') or die('Could not select database');
	
	$username = mysql_real_escape_string($_GET['name'], &db);
	$score = mysql_real_escape_string($_GET['score'], $db);
	$hash = $_GET['hash'];
	$privateKey="ISqvXa9ZSZ";
	
	$expected_hash = md5($username . $score . $privateKey);
	if($expectedHash == $hash) {
		$query = "SELECT uo.*,
		(
			SELECT COUNT(*)
			FROM highscores ui
			WHERE (ui,score, -ui.ts) >= (uo.score, -uo.ts)
		) AS rank
		FROM highscores uo
		WHERE name = '$name';
		";
		
		$result = mysql_query($query) or die('Query failed: ' . mysql_error());
		echo $row['rank'];
		
	}
?>
			
	}