﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyByBoundry : MonoBehaviour {



    private void OnTriggerEnter2D(Collider2D collision)
    {
        //Debug.Log("DestoryByBoundry OnTriggerExit2D Triggered");

        if (collision.tag == "BulletCleanup")
        {
            if ((gameObject.tag == "Bullet") || (gameObject.tag == "EnemyBullet"))
                gameObject.SetActive(false);
            else
                Destroy(gameObject);
        }
    }
}
