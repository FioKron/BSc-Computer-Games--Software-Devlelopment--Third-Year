﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class M_Camera : MonoBehaviour {

    public GameObject Player;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        
        Vector3 tmpPos = this.transform.position;
        tmpPos.y = Player.transform.position.y + 0.7f;
        this.transform.position = tmpPos;
	}
}
