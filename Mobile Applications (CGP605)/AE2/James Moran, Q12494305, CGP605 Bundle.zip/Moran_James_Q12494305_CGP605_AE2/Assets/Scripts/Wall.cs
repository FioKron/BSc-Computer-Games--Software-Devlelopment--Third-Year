﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Wall : MonoBehaviour
{
	public int totalEnemies;
	public int currentEnemies;

	// Use this for initialization
	void Start () 
	{
		currentEnemies = totalEnemies;
	}
	
	// Update is called once per frame
	void Update () 
	{
		if (currentEnemies <= 0) 
		{
			GameObject.Destroy (this.gameObject);
		}
	}
}
