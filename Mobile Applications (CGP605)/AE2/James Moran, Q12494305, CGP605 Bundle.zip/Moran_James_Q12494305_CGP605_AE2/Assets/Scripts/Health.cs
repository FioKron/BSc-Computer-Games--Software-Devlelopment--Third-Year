﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Health : MonoBehaviour {

	public Color fullHealth;
	public Color midHealth;
	public Color lowhealth;

	public Image healthFill;

	public float health =100;
	public GameObject player;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
		health = player.GetComponent<Player> ().health;
		this.GetComponent<Slider> ().value = health;
	}

	public void ValueChanged()
	{
		//Debug.Log ("value changing "+ health);

		if (health > 250)
			healthFill.color = Color.Lerp (midHealth, fullHealth, ( health - 250) / 250f);
		else if (health < 250)
			healthFill.color = Color.Lerp (lowhealth, midHealth, health / 250f);
	}
}
