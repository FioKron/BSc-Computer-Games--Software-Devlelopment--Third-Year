﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    GameObject GameManager;
	public GameObject Wall;
    public GameObject bulletPool;
    public GameObject target;

	public float movRange;
	public float speed;
	public bool direc;
	Vector3 StartPos;
    
    //shootRndInterval
    bool shooting = false;
    float timeLim;
    float timer;

	// Use this for initialization
	void Start ()
    {
        GameManager = GameObject.FindGameObjectWithTag("GameController");
        bulletPool = GameObject.Find("EnemyLaser");

        target = GameObject.FindWithTag("Player");
	}
	
	// Update is called once per frame
	void Update ()
    {
        if (!GameManager.GetComponent<GameController>().GamePaused)
        {          
            shootRndIntetval(0.5f, 3f);
			moveLR ();
        }
	}

    private void OnTriggerEnter2D(Collider2D collision)
    {
		//Debug.Log ("Enemy OnTriggerEnter2D with " + collision.tag + ".");
        if(collision.tag == "Bullet")
        {
            this.gameObject.SetActive(false);
            GameManager.GetComponent<GameController>().currentEnemies -= 1;
			if(Wall != null)
				Wall.GetComponent<Wall>().currentEnemies -= 1;

			collision.gameObject.SetActive(false);
        }
    }

	public void OnStart()
	{
        timer = Time.fixedTime;
        
		StartPos = this.transform.position;
		float tmp = Random.Range (0.0f, 1.0f);
		if (tmp < 0.5)
			direc = false;
		else
			direc = true;
		//Debug.Log ("OnStart triggered. tmp = " + tmp + " direc = " + direc);
	}

    public void moveLR()
    {
		Vector3 tmpV3 = this.transform.position;

		if (direc)
			tmpV3.x = tmpV3.x + (speed * Time.deltaTime);
		else
			tmpV3.x = tmpV3.x + (-speed * Time.deltaTime);


		if (this.transform.position.x >= (movRange + StartPos.x))
			direc = false;
		if (this.transform.position.x <= (-movRange + StartPos.x))
			direc = true;

		this.transform.position = tmpV3;
    }

    public void shoot()
    {
        GameObject bullet = bulletPool.GetComponent<ObjectPooler>().GetPooledObject();
        if (bullet != null)
        {

            bullet.SetActive(true);
            //bullet.GetComponent<Laser>().Shooter = this.gameObject;
            bullet.gameObject.transform.position = this.transform.position;
            bullet.GetComponent<Laser>().fire( this.gameObject, 1.5f, -1, true);
        }
    }

    public void shootRndIntetval(float min, float max)
    {
        if (shooting == false)
        {
            timeLim = Random.Range(min, max);
            timer = Time.fixedTime;
            shooting = true;
        }

        if ((Time.fixedTime - timer) >= timeLim)
        {
            shoot();
            shooting = false;
        }
        
    }
}
