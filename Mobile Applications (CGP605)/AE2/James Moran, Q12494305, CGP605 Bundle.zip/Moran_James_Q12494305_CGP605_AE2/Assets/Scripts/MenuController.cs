﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MenuController : MonoBehaviour {

    public GameObject highscoreCanvas;
    public GameObject highscore;
    public GameObject start;
    public GameObject quit;

    private string TopScoresURL = "https://impure-test.000webhostapp.com/TopScores.php";

    public GameObject UserColumn;
    public GameObject ScoreColum;


	void Start()
	{
		Screen.autorotateToPortrait = false;
		Screen.autorotateToPortraitUpsideDown = false;
		Screen.orientation = ScreenOrientation.AutoRotation;

        StartCoroutine(GetTopScores());
	}

	public void StartGame()
	{
		Debug.Log ("Start Game buttonpressed.");
		SceneManager.LoadScene(1);
	}

    public void HighScores()
    {
        StartCoroutine(GetTopScores());
        start.SetActive(false);
        quit.SetActive(false);
        highscore.SetActive(false);
        highscoreCanvas.SetActive(true);
    }

    public void highscoreReturn()
    {
        highscoreCanvas.SetActive(false);
        start.SetActive(true);
        quit.SetActive(true);
        highscore.SetActive(true);
    }

	public void Quit()
	{
		Debug.Log ("Quit button pressed.");
		Application.Quit();
	}

    IEnumerator GetTopScores()
    {
        Debug.Log("GetTopScores attempt");
        WWW GetScoresAttempt = new WWW (TopScoresURL);
        yield return GetScoresAttempt;

        Debug.Log("TopScores web: " + GetScoresAttempt.text);

        if (GetScoresAttempt.error != null) 
        {
            Debug.Log ("GetTopScores error: " + GetScoresAttempt.error);
        }
        else
        {
            string[] textList = GetScoresAttempt.text.Split (new string[] { "\n", "\t" }, System.StringSplitOptions.RemoveEmptyEntries);

            string[] Names = new string[Mathf.FloorToInt(textList.Length/2)];
            string[] Scores = new string[Names.Length];

            for (int i = 0; i < textList.Length; i++)
            {
                if (i % 2 == 0)
                {
                    Names[Mathf.FloorToInt(i / 2)] = textList[i];
                }
                else Scores[Mathf.FloorToInt(i / 2)] = textList[i];
            }

            int a;
            if (Names.Length < 10)
                a = Names.Length;
            else
                a = 10;

            UserColumn.GetComponent<Text>().text = "";
            ScoreColum.GetComponent<Text>().text = "";
            for (int i = 0; i < a; i++)
            {
                Debug.Log("Row: " + i);
                UserColumn.GetComponent<Text>().text += Names[i] + "\n";
                ScoreColum.GetComponent<Text>().text += Scores[i] + "\n";
            }
        }
    }

}
