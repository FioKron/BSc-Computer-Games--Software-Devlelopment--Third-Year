﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public class EnemySpawner : MonoBehaviour {

	public GameObject sprite;
	public GameObject Wall;

	public GameObject Enemy;
	public GameObject Player;

	public float PlayerProximity;
	bool spawned;


	// Use this for initialization
	void Start () {
		sprite.SetActive (false);
		spawned = false;

		Player = GameObject.FindGameObjectWithTag ("Player");
		//SpawnEnemy ();
	}
	
	// Update is called once per frame
	void Update () 
	{
		float tmpS = this.transform.position.y;
		float tmpP = Player.transform.position.y;
		if (!spawned && ((tmpS - tmpP) <= PlayerProximity)) {
			SpawnEnemy ();
		}
	}

	void SpawnEnemy()
	{
		GameObject enemy = Enemy.GetComponent<ObjectPooler>().GetPooledObject();

		Debug.Log ("Enemy trying to spawn");

		if (enemy != null) {

			enemy.SetActive (true);

			enemy.gameObject.transform.position = this.transform.position;
			enemy.GetComponent<Enemy> ().OnStart ();
			if(Wall != null)
				enemy.GetComponent<Enemy> ().Wall = Wall;

			spawned = true;
		} else
			Debug.Log ("Enemy is null");
		
	}
}
