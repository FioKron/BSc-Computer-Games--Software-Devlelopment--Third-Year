﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Laser : MonoBehaviour 
{
    //public float speed;
    public GameObject Shooter;
    float startTime;

    public GameObject GameManager;

    public Rigidbody2D rb2D;

    GameObject target;

	// Use this for initialization
	void Start () 
    {
       

        GameManager = GameObject.FindGameObjectWithTag("GameController");
        rb2D = GetComponent<Rigidbody2D>();


	}

    void Awake()
    {
        rb2D = GetComponent<Rigidbody2D>();
        target = GameObject.FindGameObjectWithTag("Player");
    }
	
	// Update is called once per frame
	void Update () 
    {
       

//        if (GameManager.GetComponent<GameController>().GamePaused == false)
//        {
//            Vector3 pos = this.gameObject.transform.position;
//            if (this.tag == "Bullet")
//                pos.y = pos.y + (speed * Time.deltaTime);
//            else if (this.tag == "EnemyBullet")
//                pos.y = pos.y + (-speed * Time.deltaTime);
//            else
//                Debug.Log("Laser has unrecognised tag.");
//            
//            this.gameObject.transform.position = pos;
//        }
	}

    public void fire( GameObject shooter, float speed, float dir, bool useTar)
    {
        Shooter = shooter;


        rb2D.velocity = Vector3.zero;
        rb2D.angularVelocity = 0f;

        if (useTar)
        {
            rb2D.AddForce((target.transform.position - this.transform.position) * speed, ForceMode2D.Impulse);

        }
        else
        {
            rb2D.AddForce(((this.transform.eulerAngles + new Vector3(0,dir,0)) - this.transform.eulerAngles) * speed, ForceMode2D.Impulse);
        }

        //rb2D.AddForce( * speed, ForceMode2D.Impulse);
    }
}
