﻿using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameController : MonoBehaviour 
{
    public GameObject PauseMenu;
    public GameObject GameOverMenu;
    public GameObject LevelMenu;
    public GameObject TimerUI;
    public GameObject HighscoreCanvas;
    public GameObject AdduserCanvas;
    float timer;
    public bool GamePaused;
    public bool GameOver;
    bool GameOverShowing;

    public bool pauseMenu;
    public bool levelMenu;

    public int totalEnemies;
    public int currentEnemies;

    public DefaultAdMobHandle AdMobHandleReference;
    private bool PauseMenuAdvertismentsLoaded = false;
    private bool PauseMenuAdvertismentsShowing = false;

    // Use this for initialization
    void Start () 
	{
        Screen.autorotateToPortrait = false;
        Screen.autorotateToPortraitUpsideDown = false;
        Screen.orientation = ScreenOrientation.AutoRotation;

        GamePaused = false;
        GameOver = false;
        GameOverShowing = false;
        pauseMenu = false;
        levelMenu = false;
        timer = 0.0f;

        currentEnemies = totalEnemies;
	}
	
	// Update is called once per frame
	void Update () 
	{
        if (!GameOverShowing && GameOver)
        {
            GameOverMenu.SetActive(true);
            GamePaused = true;
        }

        if (!GameOver && !GamePaused)
        {
            //Increment timer
            timer += 1 * Time.deltaTime;
            TimerUI.GetComponent<Text>().text = timer.ToString("#.0");
        }

        
	}


    //Pause menu functions
    public void OnPauseDown()
    {
        if (!GameOver || !pauseMenu || levelMenu)
        {
            if (!PauseMenuAdvertismentsLoaded)
            {
                AdMobHandleReference.RequestTopBanner();
                AdMobHandleReference.RequestBottomBanner();
                PauseMenuAdvertismentsLoaded = true;
            }
            else
            {
                AdMobHandleReference.ShowBanners();
                PauseMenuAdvertismentsShowing = true;
            }
            Debug.Log("Pause button pressed.");
            PauseMenu.SetActive(true);
            pauseMenu = true;
            GamePaused = true;
        }
    }

    public void OnResumeDown()
    {
        if (PauseMenuAdvertismentsShowing)
        {
            AdMobHandleReference.HideBanners();
            PauseMenuAdvertismentsShowing = false;
        }
        Debug.Log("Resume button pressed.");
        PauseMenu.SetActive(false);
        pauseMenu = false;
        GamePaused = false;
    }

	public void OnMainMenuDown()
	{
		Debug.Log ("Main Menu button pressed.");
		SceneManager.LoadScene (0);
	}

    //Game Over Menu
    public void OnRestartDown()
    {
        Debug.Log("Restart button pressed.");
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    public void OnPostScore()
    {
        LevelMenu.SetActive(false);
        AdduserCanvas.SetActive(true);
    }

    public void OnHighscore()
    {
        HighscoreCanvas.SetActive(true);
        GetComponent<Highscore>().FindTopScores();

        PauseMenu.SetActive(false);
    }

	public void LevelComplete()
	{
		//Debug.Log ("LevelComplete");
		LevelMenu.SetActive(true);
        levelMenu = true;
        GetComponent<Highscore>().SetScore(Mathf.RoundToInt(timer));
		GamePaused = true;
	}

    public void OnHighscoreReturn()
    {
        if (levelMenu)
        {
            HighscoreCanvas.SetActive(false);
            LevelMenu.SetActive(true);
        }

        if (pauseMenu)
        {
            HighscoreCanvas.SetActive(false);
            PauseMenu.SetActive(true);
        }
    }
}
