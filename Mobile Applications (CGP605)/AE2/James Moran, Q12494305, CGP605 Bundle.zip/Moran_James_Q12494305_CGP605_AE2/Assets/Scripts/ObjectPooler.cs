﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectPooler : MonoBehaviour 
{

    public List<GameObject> pooledObjects;
    public GameObject objectToPool;
    public int amountToPool;

	// Use this for initialization
	void Start () 
    {

        pooledObjects = new List<GameObject>();
        for (int i = 0; i < amountToPool; i++)
        {
            GameObject obj = Instantiate(objectToPool);
            obj.SetActive(false);
            obj.gameObject.tag = this.tag;
            obj.gameObject.layer = this.gameObject.layer;
            pooledObjects.Add(obj);
        }	
	}

    public GameObject GetPooledObject()
    {
        for (int i = 0; i < pooledObjects.Count; i++)
        {
            if (!pooledObjects[i].activeInHierarchy)
            {
                return pooledObjects[i];
            }
        }

        return null;
    }

    // For the nuke power-up entity to have
    // the intended effect:
    public void DeactivateAllEnemies()
    {
        foreach (GameObject ThisObject in pooledObjects)
        {
            // Deactivate all enemies (as per this function' name):
            //if (ThisObject.CompareTag("Enemy"))
            //{
                ThisObject.SetActive(false);
            //}
        }
    }
}
