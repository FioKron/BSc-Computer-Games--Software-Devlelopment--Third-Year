﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DoubleDamagePowerUp : PowerUpBase
{
    override protected void OnCircleOverlap()
    {
        // Enable double-damage. This power-up entity
        // is not destroyed for now as object pooling for 
        // power -up entities would
        // make sense:
        print("Double-damage activated");
        PlayerCharacterReference.EnableDamageMultiplyer();
    }
}
