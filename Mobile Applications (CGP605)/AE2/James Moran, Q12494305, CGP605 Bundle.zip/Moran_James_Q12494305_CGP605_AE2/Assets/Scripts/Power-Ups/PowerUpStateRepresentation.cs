﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/**
    A value class to store certain statistics
    about Power-Up Entities.
*/
public struct PowerUpStateRepresentation 
{
    // For how long this power-up should be active for:
    private float PowerUpDuration;

    // Whether this power-up is currently active or not:
    private bool PowerUpActive;

    // For how long the power-up has currently been active for:
    private float ActiveTime;

    private PowerUpSpawner.PowerUpType Type;

    public PowerUpStateRepresentation(PowerUpSpawner.PowerUpType PowerUpType,
        float InitialPowerUpDuration = 2.0f)
    {
        PowerUpDuration = InitialPowerUpDuration;
        PowerUpActive = false;
        ActiveTime = 0.0f;
        Type = PowerUpType;
    }

    // Get methods:
    public float GetPowerUpDuration()
    {
        return PowerUpDuration;
    }
    
    public bool GetPowerUpActive()
    {
        return PowerUpActive;
    }

    public float GetActiveTime()
    {
        return ActiveTime;
    }

    public PowerUpSpawner.PowerUpType GetPowerUpType()
    {
        return Type;
    }

    // Utility methods:
    public void ActivatePowerUp()
    {
        PowerUpActive = true;
    }

    public void DeactivatePowerUp()
    {
        PowerUpActive = false;
    }

    public void IncrementActiveTime(float IncrementationValue)
    {
        ActiveTime += IncrementationValue;
    }

    public void ResetActiveTime()
    {
        ActiveTime = 0.0f;
    }
}
