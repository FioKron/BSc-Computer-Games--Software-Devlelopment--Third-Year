﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/**
    This is the first attempt at a class for Health Power-Ups.
    They will be spawned into the level, at varying points
*/
public class HealthPowerUp : PowerUpBase
{
    // Between -1.0f and 1.0f (percent value):
    public float HealthRestorationValue = 1.0f;

    override protected void OnCircleOverlap()
    {
        print("Health restored");
        PlayerCharacterReference.ModifyHealth(HealthRestorationValue *
                        PlayerCharacterReference.MaximumHealth);
    }
}
