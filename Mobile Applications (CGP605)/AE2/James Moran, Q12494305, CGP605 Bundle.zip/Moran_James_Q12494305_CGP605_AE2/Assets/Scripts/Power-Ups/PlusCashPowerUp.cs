﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlusCashPowerUp : PowerUpBase
{
    // The value of this cash pick-up entity:
    public float CashPickupValue;

    protected override void OnCircleOverlap()
    {
        print("Cash collected");
        PlayerCharacterReference.AddToCurrencyStocked(CashPickupValue);       
    }
}
