﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FreezeAllEnemiesPowerUp : PowerUpBase
{
    protected override void OnCircleOverlap()
    {
        // No logic for now, a message is printed 
        // to the console to show this function has
        // been called:
        print("All enemies now frozen");
    }
}
