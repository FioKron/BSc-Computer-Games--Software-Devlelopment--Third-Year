﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/** 
 * The base class to use for all types of power-up entities.
 * (Now an abstract class, so that OnCircleOverlap() can
 * be an abstract method, so that all sub-classes
 * of this class have to override that method).
*/
public abstract class PowerUpBase : MonoBehaviour
{
    // Constant values:
    
    // The Player's default tag:
    protected const string PLAYER_TAG = "Player";

    // For caching the Player-Character's script:
    public Player PlayerCharacterReference;

    public PowerUpStateRepresentation CurrentState = new PowerUpStateRepresentation();

    protected void OnTriggerEnter2D(Collider2D Collider)
    {
        // (If power-up entities are spawned into the game-scene):
        PlayerCharacterReference = Collider.gameObject.GetComponent<Player>();

        // Call OnCircleOverlap if the Player has collided with this
        // power-up entity:
        if (Collider.gameObject.CompareTag(PLAYER_TAG))
        {
            print("Player has collided with power-up entity.");
            OnCircleOverlap();
            gameObject.SetActive(false);
        }
    }

    /**
        For sub-classes to use in their logic.
        Power-up entities are not destroyed at
        the moment (pooling for power-up entities
        would make sense). 
    */
    protected abstract void OnCircleOverlap();
}
