﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TemporaryInvincibilityPowerUp : PowerUpBase
{
    override protected void OnCircleOverlap()
    {
        // Enable temporary-invidiblity. This power-up entity
        // is not destroyed for now as object pooling for 
        // power -up entities would
        // make sense:
        print("Invulnerability activated.");
        PlayerCharacterReference.EnableDamageReductionMultiplyer();
    }
}
