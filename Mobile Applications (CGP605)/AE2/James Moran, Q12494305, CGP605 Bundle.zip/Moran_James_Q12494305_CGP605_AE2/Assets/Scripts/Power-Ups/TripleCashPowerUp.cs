﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TripleCashPowerUp : PowerUpBase
{
    override protected void OnCircleOverlap()
    {
        // Enable triple-cash for currency pick-up entities.
        // This power-up entity is not destroyed for now as 
        // object pooling for power -up entities would
        // make sense:
        print("Triple-cash activated");
        PlayerCharacterReference.EnableCashPickUpMultiplyer();
    }
}
