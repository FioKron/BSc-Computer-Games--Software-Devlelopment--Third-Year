﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


/**
    This class is for spawning power-up entities
    into the level (from the object pools).
*/
public class PowerUpSpawner : MonoBehaviour
{
    // Enumerations:

    // For all types of power-up entities:
    public enum PowerUpType
    {
        // Starting from 1 (for mentioning this to a person not in the field):
        FullHealth = 1,
        FreezeAllEnemies = 2,
        DoublePoints = 3,
        DoubleDamage = 4,
        MovementSpeed = 5,
        ReloadSpeed = 6,
        TripleCash = 7,
        Invulnerability = 8
    }

    // Properties:

    // For each type of power-up:
    public GameObject FullHealthPowerUpEntities;
    public GameObject FreezeAllEnemiesPowerUpEntities;
    public GameObject DoublePointsPowerUpEntities;
    public GameObject MovementSpeedPowerUpEntities;
    public GameObject ReloadSpeedPowerUpEntities;
    private const int NUMBER_OF_POWER_UP_ENTITIES = 5;

    // For a reference location to spawn the power-up:
    public GameObject PlayerGameObjectReference;

    // To manage when power-up entities are spawned into the game world:
    private float ElapsedTime = 0.0f;
    public float PowerUpSpawnFrequency = 10.0f;
    // For the radius of a circle cast around the Player,
    // which is then offset by the Player position:
    public int SPAWN_CIRCLE_RADIUS = 2;

    // Functions:

    // Spawn a power-up near the Player every PowerUpSpawnFrequency seconds:
    private void Update()
    {
        ElapsedTime += Time.deltaTime;
        
        if (ElapsedTime >= PowerUpSpawnFrequency)
        {
            SpawnPowerUp();
        }
    }

    // Spawn a power-up based on the value of PowerUpToSpawn:
    private void SpawnPowerUp()
    {
        PowerUpType PowerUpTypeToSpawn = (PowerUpType)Random.Range(0, NUMBER_OF_POWER_UP_ENTITIES);
        GameObject PowerUpToSpawn = new GameObject();
        
        switch (PowerUpTypeToSpawn)
        {
        case PowerUpType.FullHealth:
            PowerUpToSpawn = FullHealthPowerUpEntities.GetComponent<ObjectPooler>().GetPooledObject();
            break;

        case PowerUpType.FreezeAllEnemies:
            PowerUpToSpawn = FreezeAllEnemiesPowerUpEntities.GetComponent<ObjectPooler>().GetPooledObject();
            break;

        case PowerUpType.DoublePoints:
            PowerUpToSpawn = DoublePointsPowerUpEntities.GetComponent<ObjectPooler>().GetPooledObject();
            break;

        case PowerUpType.MovementSpeed:
            PowerUpToSpawn = MovementSpeedPowerUpEntities.GetComponent<ObjectPooler>().GetPooledObject();
            break;

        case PowerUpType.ReloadSpeed:
            PowerUpToSpawn = ReloadSpeedPowerUpEntities.GetComponent<ObjectPooler>().GetPooledObject();
            break;
        }
          
        Vector3 SpawnLocation = (Random.insideUnitCircle * SPAWN_CIRCLE_RADIUS) +
            (Vector2) PlayerGameObjectReference.transform.position;

        if (PowerUpToSpawn != null)
        {
            PowerUpToSpawn.transform.position = SpawnLocation;
            PowerUpToSpawn.SetActive(true);
        }            
    }
}
