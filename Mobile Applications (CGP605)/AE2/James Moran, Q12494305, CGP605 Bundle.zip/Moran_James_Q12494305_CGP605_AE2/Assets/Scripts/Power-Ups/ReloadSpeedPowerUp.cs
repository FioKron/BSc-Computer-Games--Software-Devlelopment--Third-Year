﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ReloadSpeedPowerUp : PowerUpBase
{
    // To alter how often the Player can 'reload' their ship's weapon:
    // (Default value subtracts 30% from the delay the Player has to wait
    // for, before firing another shot):
    public float ReloadSpeedMultiplyer = 0.70f;

    override protected void OnCircleOverlap()
    {
        print("Reload-Speed Power-Up overlapped");
        PlayerCharacterReference.ApplyReloadSpeedModifier
            (ReloadSpeedMultiplyer); 
    }
}
