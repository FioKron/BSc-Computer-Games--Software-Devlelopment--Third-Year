﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovementSpeedPowerUp : PowerUpBase
{
    // The value to multiply movement speed by
    // (default value of 2.5):
    public float MovementSpeedMultiplyer = 2.50f;
    override protected void OnCircleOverlap()
    {
        print("Movement-speed increased");
        PlayerCharacterReference.ApplyMovementSpeedModifier
            (MovementSpeedMultiplyer);
    }
}
