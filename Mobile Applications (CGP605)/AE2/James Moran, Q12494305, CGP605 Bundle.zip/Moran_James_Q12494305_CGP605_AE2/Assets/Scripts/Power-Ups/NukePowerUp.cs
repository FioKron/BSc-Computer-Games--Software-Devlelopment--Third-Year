﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NukePowerUp : PowerUpBase
{
    // To deactivate all of the enemies on screen:
    public ObjectPooler EnemyPool;

    protected override void OnCircleOverlap()
    {
        // Deactivate all active enemies (to, in
        // effect, remove them from the Player's
        // sight):
        print("Nuke activated");
        EnemyPool.DeactivateAllEnemies();
    }
}
