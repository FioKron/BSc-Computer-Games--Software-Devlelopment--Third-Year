﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StarGenerator : MonoBehaviour 
{
    

    public GameObject Star;
    public int NoStars;
    float Brightness = 0;

    Vector3 GameArea;

	// Use this for initialization
	void Start () 
    {
		
        
        
		GameArea = this.GetComponent<SpriteRenderer>().bounds.size; 
		GameArea.x = GameArea.x / 2;
		GameArea.y = (GameArea.y / 2);

		float posY = this.transform.position.y;

        for (int i = 0; i < NoStars; i++)
        {
			Vector3 StarPos = new Vector3(Random.Range(-GameArea.x, GameArea.x), Random.Range(-GameArea.y + posY, GameArea.y + posY), 0);
            GameObject star = Instantiate(Star, StarPos, Quaternion.identity, this.transform);

            star.GetComponent<SpriteRenderer>().color = new Color(Random.Range(Brightness, 1), Random.Range(Brightness, 1), Random.Range(Brightness, 1));
			star.GetComponent<SpriteRenderer> ().sortingOrder = -1;

        }
	}
	
	// Update is called once per frame
	void Update () 
    {
		
	}
}
