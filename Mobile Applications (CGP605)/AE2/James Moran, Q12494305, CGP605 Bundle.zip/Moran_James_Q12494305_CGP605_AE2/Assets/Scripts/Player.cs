﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public GameObject GameManager;
    
    public float keySpeed;
    public float touchSpeed;
    public GameObject bulletPool;

    bool tapped = false;

    Rigidbody2D rb;
    Vector2 thrust;

	public float health;
    // For the Health-Power-Up to use:
    public float MaximumHealth = 500.0f;

    // To manage how often the Player can fire shots:
    private const float DEFAULT_LASER_SHOT_DELAY = 0.250f;
    public float LaserShotDelay = DEFAULT_LASER_SHOT_DELAY;
    public float TimeSinceLastShot;
    public float NonBoostedReloadSpeed;

    // For the MovementSpeedPowerUp to have an effect on the Player:
    public const float DEFAULT_MOVEMENT_SPEED = 1.0f;
    public float MovementSpeed = DEFAULT_MOVEMENT_SPEED;
    public float NonBoostedMovementSpeed;

    private List<PowerUpStateRepresentation> PowerUpEntityState = new List<PowerUpStateRepresentation>();

    // Update the time that a power-up entity is active for,
    // for all active power-up entities:
    private void UpdatePowerUpActiveTime()
    {
        foreach (PowerUpStateRepresentation CurrentPowerUpState 
            in PowerUpEntityState)
        {
            if (CurrentPowerUpState.GetActiveTime() >= CurrentPowerUpState.GetPowerUpDuration())
            {
                CurrentPowerUpState.DeactivatePowerUp();
            }

            CurrentPowerUpState.IncrementActiveTime(Time.deltaTime);
        }
    }

    // To check on the state of a certain type of power-up entity:
    private PowerUpStateRepresentation GetPowerUpEntityState(PowerUpSpawner.PowerUpType TargetPowerUp)
    {
        // The return value:
        foreach (PowerUpStateRepresentation CurrentListValue in PowerUpEntityState)
        {
            if (CurrentListValue.GetPowerUpType() == TargetPowerUp)
            {
                return CurrentListValue;                
            }
        }

        return new PowerUpStateRepresentation();
    }
    // For timing how long power-up entities are active:
    private float PowerUpDuration = 0.0f;

    // Constant values for the default state modification
    // power-up enitities:
    private const float DEFAULT_DAMAGE_MULTIPLYER = 2.0f;
    private const float DEFAULT_DAMAGE_REDUCTION_MULTIPLYER = 0.0f;
    private const float DEFAULT_CASH_PICK_UP_MULTIPLYER = 3.0f;
    private const float DEFAULT_POINTS_MULTIPLYER = 2.0f;

    // To store the currency the Player has:
    public float CurrencyStocked = 0.0f;

    // Use this for initialization
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        health = MaximumHealth;
        // As the Player has not yet fired a shot when the game begins:
        TimeSinceLastShot = LaserShotDelay;
        InitialisePowerUpState();
    }

    // Subject to updating later for the respective types of power-up entities:
    private void InitialisePowerUpState()
    {
        // Add states for each type of power-up entity:
        PowerUpEntityState.Add(new PowerUpStateRepresentation(PowerUpSpawner.PowerUpType.DoubleDamage));
        PowerUpEntityState.Add(new PowerUpStateRepresentation(PowerUpSpawner.PowerUpType.DoublePoints));
        PowerUpEntityState.Add(new PowerUpStateRepresentation(PowerUpSpawner.PowerUpType.FreezeAllEnemies));
        PowerUpEntityState.Add(new PowerUpStateRepresentation(PowerUpSpawner.PowerUpType.FullHealth));
        PowerUpEntityState.Add(new PowerUpStateRepresentation(PowerUpSpawner.PowerUpType.Invulnerability));
        PowerUpEntityState.Add(new PowerUpStateRepresentation(PowerUpSpawner.PowerUpType.MovementSpeed));
        PowerUpEntityState.Add(new PowerUpStateRepresentation(PowerUpSpawner.PowerUpType.ReloadSpeed));
        PowerUpEntityState.Add(new PowerUpStateRepresentation(PowerUpSpawner.PowerUpType.TripleCash));
    }

    void Update ()
    {
        bool GamePaused = GameManager.GetComponent<GameController>().GamePaused;

        TimeSinceLastShot += Time.deltaTime;      

        if (GamePaused == false)
        {
            if (health < 1)
                GameManager.GetComponent<GameController>().GameOver = true;
            PCControls();
            MobControls();

            UpdatePowerUpActiveTime();
        }
    }

    // To manage upgrading the Player's health: 
    public void UpgradeMaxHealth(float MaximumHealthIncrementor, float UpgradeCost)
    {
        MaximumHealth += MaximumHealthIncrementor;
        health = MaximumHealth;
        print("Health Upgrade Purchased");
        AddToCurrencyStocked(-UpgradeCost);
    }

    // To manage upgrading the Player's movement speed:
    public void UpgradeMaxSpeed(float SpeedPercentageAddition, float UpgradeCost)
    {
        MovementSpeed += SpeedPercentageAddition * DEFAULT_MOVEMENT_SPEED;
        print("Movement Speed Upgrade Purchased");
        AddToCurrencyStocked(-UpgradeCost);
    }

    // Change the Player's health, then validate the new health
    // value (negative to reduce health, positive to gain health):
    public void ModifyHealth(float HealthModificationValue)
    {
        // Check to see if the Player's health is intended for reduction...
        if (HealthModificationValue < 0)
        {
            // ...then check to see if the invulnerability power-up is active,            
            // if so...multiply the modification value by the default reduction 
            // value (0), thus negating the damage:
            if (GetPowerUpEntityState(PowerUpSpawner.PowerUpType.Invulnerability).GetPowerUpActive())
            {
                HealthModificationValue *= DEFAULT_DAMAGE_REDUCTION_MULTIPLYER;
            }
        }
        
        health += HealthModificationValue;
        ValidateHealth();
    }

    // For keeping the Player's health between 0 and MaximumHealth:
    private void ValidateHealth()
    {
        if (health >= MaximumHealth)
        {
            health = MaximumHealth;
        }
        else if (health <= 0.0f)
        {
            health = 0.0f;
        }
    }

    // For modifiying 'reload' speed:
    public void ApplyReloadSpeedModifier(float ReloadSpeedMultiplyer)
    {
        if (!GetPowerUpEntityState(PowerUpSpawner.PowerUpType.ReloadSpeed).
            GetPowerUpActive())
        {
            NonBoostedReloadSpeed = LaserShotDelay;
            LaserShotDelay *= ReloadSpeedMultiplyer;
            EnableReloadSpeedPowerUp();
        }
    }

    // For reseting the Player's 'reload' speed after the power-up duration ends:
    public void ResetReloadSpeed()
    {
        LaserShotDelay = NonBoostedReloadSpeed;
        DisableReloadSpeedPowerUp();
    }

    // If the Player collects a movement-speed power-up...
    public void ApplyMovementSpeedModifier(float MovementSpeedMultiplyer)
    {
        if (!GetPowerUpEntityState(PowerUpSpawner.PowerUpType.MovementSpeed).
            GetPowerUpActive())
        {
            NonBoostedMovementSpeed = MovementSpeed;
            MovementSpeed *= MovementSpeedMultiplyer;
            EnableMovementSpeedPowerUp();
        }           
    }

    // For resetting the Player's movement speed after the power-up duration ends:
    public void ResetMovementSpeed()
    {
        MovementSpeed = NonBoostedMovementSpeed;
        DisableMovementSpeedPowerUp();
    }

    // Increase/decrease the Player's stockpiled cash, 
    // if they pick up a cash power-up: (Positive to increase,
    // negative to decrease):
    public void AddToCurrencyStocked(float CurrencyPowerUpValue)
    {
        // Triple the amount of currency the Player gains
        // if tripple cash is active:
        if (GetPowerUpEntityState(PowerUpSpawner.PowerUpType.ReloadSpeed).GetPowerUpActive())
        {
            CurrencyPowerUpValue *= DEFAULT_CASH_PICK_UP_MULTIPLYER;
        }

        CurrencyStocked += CurrencyPowerUpValue;
        print("Current currency stockpiled: " + CurrencyStocked);
    }

    public void EnableDamageMultiplyer()
    {
        GetPowerUpEntityState(PowerUpSpawner.PowerUpType.DoubleDamage).
            ActivatePowerUp();
    }

    public void DisableDamageMultiplyer()
    {
        GetPowerUpEntityState(PowerUpSpawner.PowerUpType.DoubleDamage).
            DeactivatePowerUp();
    }

    public void EnableDamageReductionMultiplyer()
    {
        GetPowerUpEntityState(PowerUpSpawner.PowerUpType.Invulnerability).
            ActivatePowerUp();
    }

    public void DisableDamageReductionMultiplyer()
    {
        GetPowerUpEntityState(PowerUpSpawner.PowerUpType.Invulnerability).
            DeactivatePowerUp();
    }

    public void EnableCashPickUpMultiplyer()
    {
        GetPowerUpEntityState(PowerUpSpawner.PowerUpType.TripleCash).
            ActivatePowerUp();
    }

    public void DisableCashPickUpMultiplyer()
    {
        GetPowerUpEntityState(PowerUpSpawner.PowerUpType.TripleCash).
            DeactivatePowerUp();
    }

    public void EnablePointsMultiplyer()
    {
        GetPowerUpEntityState(PowerUpSpawner.PowerUpType.DoublePoints).
            ActivatePowerUp();
    }

    public void DisablePointsMultiplyer()
    {
        GetPowerUpEntityState(PowerUpSpawner.PowerUpType.DoublePoints).
            DeactivatePowerUp();
    }

    public void EnableMovementSpeedPowerUp()
    {
        GetPowerUpEntityState(PowerUpSpawner.PowerUpType.MovementSpeed).
            ActivatePowerUp();
    }

    public void DisableMovementSpeedPowerUp()
    {
        GetPowerUpEntityState(PowerUpSpawner.PowerUpType.MovementSpeed).
            DeactivatePowerUp();
    }

    public void EnableReloadSpeedPowerUp()
    {
        GetPowerUpEntityState(PowerUpSpawner.PowerUpType.ReloadSpeed).
            ActivatePowerUp();
    }

    public void DisableReloadSpeedPowerUp()
    {
        GetPowerUpEntityState(PowerUpSpawner.PowerUpType.ReloadSpeed).
            DeactivatePowerUp();
    }

    // Get functions:
    public float GetCurrencyStocked()
    {
        return CurrencyStocked;
    }

    private void OnCollisionExit2D(Collision2D coll)
    {
        //Debug.Log("Player hit something");
        if(coll.collider.tag == "Boundary")
        {
            //Debug.Log("Player hit boundary");
            Vector2 force = coll.relativeVelocity;
            GetComponent<Rigidbody2D>().AddForce(force, ForceMode2D.Impulse);
        }
    }

	private void OnTriggerEnter2D(Collider2D coll)
	{
		Debug.Log ("Player OnTriggerEnter2D with " + coll.name + ".");

		if (coll.tag == "EnemyBullet") 
		{
			if (health > 0)
            {
                // As a test here:
                const float BULLET_DAMAGE_VALUE = 30.0f;
                ModifyHealth(-BULLET_DAMAGE_VALUE);
			}
		}

		if (coll.tag == "LevelEnd") 
		{
			//Debug.Log ("LevelEnd if statement.");
			GameManager.GetComponent<GameController> ().LevelComplete ();
		}
	}

    void PCControls()
    {
        thrust = new Vector2(Input.GetAxis("Horizontal"), Input.GetAxis("Vertical"));
        rb.AddForce(thrust * keySpeed * MovementSpeed * Time.deltaTime, ForceMode2D.Impulse);

        if (Input.GetButtonDown("Fire"))
            fireLaser();
    }

    void MobControls()
    {
        int a = 0;
        int b = 1;

        //For each finger
        for (int i = 0; i < Input.touchCount; i++)
        {


            //First finger
            if (i == a)
            {
                touchMov(i);
            }
            //Second finger
            if (i == b)
            {
                if (tapped != true)
                {
                    touchMov(i);

                    fireLaser();

                    tapped = true;
                }

            }

            if ((Input.GetTouch(b).phase != TouchPhase.Ended) && (Input.GetTouch(a).phase == TouchPhase.Ended))
            {
                a = 1;
                b = 0;
            }

            if (Input.GetTouch(i).phase == TouchPhase.Ended)
                tapped = false;

        }
    }

    void touchMov(int i)
    {     
        Vector2 touchDeltaPos = Input.GetTouch(0).deltaPosition;
        rb.AddForce(new Vector2(touchDeltaPos.x * touchSpeed * MovementSpeed,
            touchDeltaPos.y * touchSpeed * MovementSpeed), ForceMode2D.Impulse);
    }

    void fireLaser()
    {
        GameObject bullet = bulletPool.GetComponent<ObjectPooler>().GetPooledObject();
        // Only allow shooting every LaserShotDelay seconds:
        if (bullet != null && TimeSinceLastShot >= LaserShotDelay)
        {
            TimeSinceLastShot = 0.0f;
            bullet.SetActive(true);
            //bullet.GetComponent<Laser>().Shooter = this.gameObject;
            bullet.gameObject.transform.position = this.transform.position;
            bullet.GetComponent<Laser>().fire( this.gameObject, 1.5f, 1, false);
        }

    }
}
