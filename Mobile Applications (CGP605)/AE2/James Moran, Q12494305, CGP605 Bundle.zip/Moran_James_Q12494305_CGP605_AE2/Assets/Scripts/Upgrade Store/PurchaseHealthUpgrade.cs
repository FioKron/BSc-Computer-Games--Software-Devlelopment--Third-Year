﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/** 
 * For whenever the Player purchases a health upgrade 
 */
public class PurchaseHealthUpgrade : MonoBehaviour
{
    /** The health to provide to the Player */
    public float HealthAddition;

    /** To refer to the Player's script*/
    public Player PlayerScriptReference;

    /** The cost of this upgrade */
    public float UpgradeCost;
	
    // Initiate the process for purchasing this upgrade:
    public void PurchaseUpgrade()
    {
        if (UpgradeCost > PlayerScriptReference.GetCurrencyStocked())
        {
            print("Player is not able to afford this upgrade!");
        }
        else
        {
            PlayerScriptReference.UpgradeMaxHealth(HealthAddition, UpgradeCost);
        }       
    }
}
