﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class Highscore : MonoBehaviour {


	
	public GameObject UsernameCanvas;
	public GameObject Highscores;
	public GameObject Username;

	public GameObject UserColumn;
	public GameObject ScoreColum;

	//Highscore variables
	private string privateKey = "ISqvXa9ZSZ";
	private string AddScoreURL = "https://impure-test.000webhostapp.com/AddScore.php?";
	private string TopScoresURL = "https://impure-test.000webhostapp.com/TopScores.php";
	private int highscore;
	private string username;
	private int rank;

	private IEnumerator coroutine;

    public void start()
    {
        StartCoroutine(GetTopScores());
    }

	public void SetName (string name)
	{
		username = name;
	}

	public void SetScore(int score)
	{
		highscore = score;
	}

    public void FindTopScores()
    {
        StartCoroutine(GetTopScores());
    }

	IEnumerator AddScore(int score, string name)
	{
		Debug.Log("AddScore attempt");
		string hash = Md5Sum (name + score + privateKey);

		WWW ScorePost = new WWW(AddScoreURL + "name=" + WWW.EscapeURL(name) + "&score=" + score + "&hash=" + hash);
		yield return ScorePost;

		Debug.Log("AddUser web: " + ScorePost.text);

		if (ScorePost.error == null)
		{
			//StartCoroutine(GrabRank(score, name));
			StartCoroutine(GetTopScores());
		}
		else
		{
			Debug.Log ("AddScore error: " + ScorePost.error);
		}
	}
        

	IEnumerator GetTopScores()
	{
		Debug.Log("GetTopScores attempt");
		WWW GetScoresAttempt = new WWW (TopScoresURL);
		yield return GetScoresAttempt;

		Debug.Log("TopScores web: " + GetScoresAttempt.text);

		if (GetScoresAttempt.error != null) 
		{
			Debug.Log ("GetTopScores error: " + GetScoresAttempt.error);
		}
		else
		{
			string[] textList = GetScoresAttempt.text.Split (new string[] { "\n", "\t" }, System.StringSplitOptions.RemoveEmptyEntries);

			string[] Names = new string[Mathf.FloorToInt(textList.Length/2)];
			string[] Scores = new string[Names.Length];

			for (int i = 0; i < textList.Length; i++)
			{
				if (i % 2 == 0)
				{
					Names[Mathf.FloorToInt(i / 2)] = textList[i];
				}
				else Scores[Mathf.FloorToInt(i / 2)] = textList[i];
			}

			int a;
			if (Names.Length < 10)
				a = Names.Length;
			else
				a = 10;

			UserColumn.GetComponent<Text>().text = "";
			ScoreColum.GetComponent<Text>().text = "";
			for (int i = 0; i < a; i++)
			{
				Debug.Log("Row: " + i);
				UserColumn.GetComponent<Text>().text += Names[i] + "\n";
				ScoreColum.GetComponent<Text>().text += Scores[i] + "\n";
			}
		}
	}

	public void OnClickUsernameEnter()
	{
		SetName (Username.GetComponent<Text>().text);

		
		UsernameCanvas.SetActive(false);
		Highscores.SetActive(true);

		if (username != null) 
		{
			Debug.Log("username != null");
			StartCoroutine(AddScore(highscore, username));
		}
		else
			Debug.Log ("No username.");
	}

	//MD5 hash function by Mathew Wegner wiki.unity3D.com/index.php?title=MD%
	public  string Md5Sum(string strToEncrypt)
	{
		System.Text.UTF8Encoding ue = new System.Text.UTF8Encoding();
		byte[] bytes = ue.GetBytes(strToEncrypt);
	 
		// encrypt bytes
		System.Security.Cryptography.MD5CryptoServiceProvider md5 = new System.Security.Cryptography.MD5CryptoServiceProvider();
		byte[] hashBytes = md5.ComputeHash(bytes);
	 
		// Convert the encrypted bytes back to a string (base 16)
		string hashString = "";
	 
		for (int i = 0; i < hashBytes.Length; i++)
		{
			hashString += System.Convert.ToString(hashBytes[i], 16).PadLeft(2, '0');
		}
	 
		return hashString.PadLeft(32, '0');
	}
}
