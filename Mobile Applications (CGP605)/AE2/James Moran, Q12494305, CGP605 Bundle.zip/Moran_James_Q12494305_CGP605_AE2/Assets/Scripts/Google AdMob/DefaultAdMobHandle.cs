﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using GoogleMobileAds.Api;

public class DefaultAdMobHandle : MonoBehaviour
{
    private BannerView DefaultBannerView;
    
    public void RequestTopBanner()
    {
        #if UNITY_ANDROID       
            string ADUnitID = "ca-app-pub-1431981835999844/4982610125";
        #else
            string ADUnitID = "unexpected_platform";
        #endif
        
        // Create a 320x50 banner at the top of the screen.
        DefaultBannerView = new BannerView(ADUnitID, AdSize.Banner, AdPosition.Top);

        // Create an empty ad request.
        AdRequest Request = new AdRequest.Builder()
            .AddTestDevice(AdRequest.TestDeviceSimulator) // 'Simulator.'
            .AddTestDevice("6EE45418C000A18430F4BC0BAD42B16B")  // 'test device.'
            .Build();

            // Load the banner with the request.
            DefaultBannerView.LoadAd(Request);
    }

    public void RequestBottomBanner()
    {
        #if UNITY_ANDROID
            string ADUnitID = "ca-app-pub-1431981835999844/4982610125";
        #else
            string ADUnitID = "unexpected_platform";
        #endif

        // Create a 320x50 banner at the bottom of the screen.
        DefaultBannerView = new BannerView(ADUnitID, AdSize.Banner, AdPosition.Bottom);

        // Create an empty ad request.
        AdRequest Request = new AdRequest.Builder()
            .AddTestDevice(AdRequest.TestDeviceSimulator) // 'Simulator.'
            .AddTestDevice("16E28B558CE4395071320F7F3BC2CC3F")  // 'test device.'
            .Build();

        // Load the banner with the request.
        DefaultBannerView.LoadAd(Request);
    }

    public void HideBanners()
    {
        DefaultBannerView.Hide();
    }

    public void ShowBanners()
    {
        DefaultBannerView.Show();
    }
}
