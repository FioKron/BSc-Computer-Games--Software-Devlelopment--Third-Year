#pragma once

#include <d3d11.h>

#define _XM_NO_INTRINSICS_
#define XM_NO_ALIGNMENT
#include <xnamath.h>

#include <math.h>

/**
	Reformed this class to match up to the ArcCamera class,
	as detailed on p334-340 of Beginning DirectX 11 Game
	Programming.
	
	This was due to issues with the first implementation of 
	this class (trying to set-up the camera to act as a 
	third-person camera).
*/
class Camera
{

private:

	// Properties:

	XMFLOAT3 Position;
	XMFLOAT3 Target;

	float CurrentDistanceToTarget, MinimumDistance,
		MaximumDistance;
	float XRotation, YRotation,
		MinimumYRotation, MaximumYRotation;
	
	// Functions:

	/** 
		Validate that a float value is 
		between LowerBound and UpperBound.
	*/
	float ValidateFloatValue(float Value, float LowerBound,
		float UpperBound);
	
public:

	// Functions:

	/** Standard constructor. */
	Camera();

	/** Standard destructor. */
	~Camera();

	// Set methods:
	void SetDistance(float NewDistance, float
		NewMinimumDistance, float NewMaximumDistance);
	void SetRotation(float NewX, float NewY, float
		NewMinimumY, float NewMaximumY);
	void SetTarget(XMFLOAT3& NewTarget);

	// Get Functions:

	XMMATRIX GetViewMatrix();

	// Properties:

	// Constant values:
	
	/** For the default target and position values. */
	const XMFLOAT3 ZERO_FLOAT3 = XMFLOAT3(0.0f, 0.0f, 0.0f);
	const XMFLOAT3 DEFAULT_POSITION = XMFLOAT3(0.0f, 0.0f, 0.0f);
	const float Y_POSITION_OFFSET = 30.0f;
	
	/** 
		The default distance from the Target and the 
		bounds of this distance.
	*/
	const float DEFAULT_DISTANCE = 50.0f;
	const float DEFAULT_MINIMUM_DISTANCE = 1.0f;
	const float DEFAULT_MAXIMUM_DISTANCE = 100.0f;

	/**
		The default rotation values.
		(In radians).
	*/
	const float DEFAULT_X_ROTATION = 0.0f;
	const float DEFAULT_Y_ROTATION = 0.0f;
};

