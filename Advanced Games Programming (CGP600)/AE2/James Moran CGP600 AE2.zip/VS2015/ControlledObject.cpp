#include "ControlledObject.h"

// Structures:

struct MODEL_CONSTANT_BUFFER
{
	XMMATRIX WorldViewProjectionMatrix; // '64 bytes ( 4 x 4 = 16 floats x 4 bytes)'
	XMVECTOR DirectionalLightVector; // '16 bytes'
	XMVECTOR DirectionalLightColour; // '16 bytes'
	XMVECTOR AmbientLightColour; // '16 bytes'
}; // 'TOTAL SIZE = 112 bytes'

// Initialise (using an initialiser list):
ControlledObject::ControlledObject(ID3D11Device*& NewD3DDeviceReference, 
	ID3D11DeviceContext*& NewD3DDeviceContextReference, 
	HRESULT& ResultHandleReference, XMFLOAT3& InitialPosition) 
	: GameObject(NewD3DDeviceReference, NewD3DDeviceContextReference, 
		ResultHandleReference, InitialPosition)
{
	// Set-up the default directions...
	DefaultForwardDirection = XMVectorSet(0.0f, 0.0f, 1.0f, 0.0f);
	DefaultRightDirection = XMVectorSet(1.0f, 0.0f, 0.0f, 0.0f);
	DefaultUpDirection = XMVectorSet(0.0f, 1.0f, 0.0f, 0.0f);

	// ...then initialise the object's directions...
	ObjectForwardDirection = DefaultForwardDirection;
	ObjectRightDirection = DefaultRightDirection;
	ObjectUpDirection = DefaultUpDirection;

	// ...before initialising the translation and rotation values:
	MovementLeftRight = 0.0f;
	MovementForwardBackwards = 0.0f;
	MovementUpDown = 0.0f;
	ObjectMovementDirection = XMVectorSet(0.0f, 0.0f, 0.0f, 0.0f);
}

// Clean-up:
ControlledObject::~ControlledObject()
{

}

void ControlledObject::Draw(XMMATRIX* View, XMMATRIX* Projection)
{
	// Also taken from the tutorial mentioned in the header file 
	// (of the Camera class, as parts of this function was taken 
	// from the Camera.cpp):

	// Perform degrees to radians conversions first though:
	float PitchRotationRadians = XMConvertToRadians(RotationVector.x);
	float YawRotationRadians = XMConvertToRadians(RotationVector.y);
	float RollRotationRadians = XMConvertToRadians(RotationVector.z);

	RotationMatrix = XMMatrixRotationRollPitchYaw(PitchRotationRadians,
		YawRotationRadians, RollRotationRadians);
	ObjectForwardTarget = XMVector3TransformCoord(DefaultForwardDirection,
		RotationMatrix);
	ObjectForwardTarget = XMVector3Normalize(ObjectForwardTarget);

	XMMATRIX RotateYTempMatrix = XMMatrixRotationY(YawRotationRadians);

	ObjectRightDirection = XMVector3TransformCoord(DefaultRightDirection, RotateYTempMatrix);
	ObjectUpDirection = XMVector3TransformCoord(DefaultUpDirection, RotateYTempMatrix);
	ObjectForwardDirection = XMVector3TransformCoord(DefaultForwardDirection, RotateYTempMatrix);

	// Update the position (and current movement direction), for movement:
	XMVECTOR HorizontalMovementVelocity = MovementLeftRight * ObjectRightDirection;
	XMVECTOR VerticalMovementVelocity = MovementUpDown * ObjectUpDirection;
	XMVECTOR DepthMovementVelocity = MovementForwardBackwards * ObjectForwardDirection;

	PositionVector += HorizontalMovementVelocity;
	PositionVector += DepthMovementVelocity;

	// Set the movement-direction to HorizontalMovementVelocity
	// before incrementing it by depth and height:
	ObjectMovementDirection = HorizontalMovementVelocity;
	ObjectMovementDirection += DepthMovementVelocity;
	ObjectMovementDirection += VerticalMovementVelocity;
	ObjectMovementDirection = XMVector3Normalize(ObjectMovementDirection);

	MovementLeftRight = 0.0f;
	MovementForwardBackwards = 0.0f;
	MovementUpDown = 0.0f;

	ObjectForwardTarget += PositionVector;

	// Update the World transform matrix and the buffers now:

	// Scale first, then rotation, with translation as the last of 
	// the transformation actions to take place:
	World = XMMatrixScalingFromVector(ObjectScaleVector);
	World *= XMMatrixRotationRollPitchYaw(PitchRotationRadians,
		YawRotationRadians, RollRotationRadians);
	World *= XMMatrixTranslationFromVector(PositionVector);
	
	// For lighting on this object:
	XMMATRIX TransposeMatrix = XMMATRIX();
	MODEL_CONSTANT_BUFFER ObjectConstantBufferValues;
	ObjectConstantBufferValues.WorldViewProjectionMatrix = World * (*View) * (*Projection);

	ObjectConstantBufferValues.DirectionalLightColour = DirectionalLightColour;
	ObjectConstantBufferValues.AmbientLightColour = AmbientLightColour;
	ObjectConstantBufferValues.DirectionalLightVector = XMVector3Transform(DirectionalLightShinesFrom,
		TransposeMatrix);
	ObjectConstantBufferValues.DirectionalLightVector = XMVector3Normalize(ObjectConstantBufferValues.
		DirectionalLightVector);

	ImmediateContextReference->VSSetConstantBuffers(0u, 1u, &GameObjectConstantBufferReference);
	ImmediateContextReference->UpdateSubresource(GameObjectConstantBufferReference, 0u, nullptr,
		&ObjectConstantBufferValues, 0u, 0u);

	// Set this model's shaders and input layout as active:
	ImmediateContextReference->VSSetShader(GameObjectVertexShaderReference, nullptr, 0);
	ImmediateContextReference->PSSetShader(GameObjectPixelShaderReference, nullptr, 0);
	ImmediateContextReference->IASetInputLayout(GameObjectInputLayoutReference);

	ObjectModelReference->Draw();
}

/** 
	Parse in a positive value for the direction as
	per the function name, or a negative value for the
	opposite direction. 
*/

// Add Z-Axis offset to the object:
void ControlledObject::MoveForward(float DisplacementValue)
{
	MovementForwardBackwards -= DisplacementValue;
}

// Add X-Axis offset to the object:
void ControlledObject::MoveRight(float DisplacementValue)
{
	MovementLeftRight -= DisplacementValue;
}

// Repel this object from a static-object:
void ControlledObject::RepelControlledObject(float RepulsionMagnitude)
{
	PositionVector += -(ObjectMovementDirection * RepulsionMagnitude);
}

XMVECTOR& ControlledObject::GetObjectMovementDirection()
{
	return ObjectMovementDirection;
}
