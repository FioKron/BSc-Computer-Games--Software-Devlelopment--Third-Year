#pragma once
#include "ControlledObject.h"
#include "PlayerHoverTank.h"

class EnemyHoverTank : public ControlledObject
{

public:

	// Enumerations:

	/** 
		For the current state this tank is in
		(on the Finite State Machine).
	*/
	enum AIState
	{
		Initial,
		HasTarget,
		MovingToTarget
	};

	// Functions:

	/** Standard constructor. */
	EnemyHoverTank(ID3D11Device*& NewD3DDeviceReference, ID3D11DeviceContext*&
		NewD3DDeviceContextReference, HRESULT& ResultHandleReference,
		XMFLOAT3& InitialPosition);

	/** Standard destructor. */
	~EnemyHoverTank();

	/** For state mangement. */
	void ManageAIState(PlayerHoverTank*& 
		PlayerHoverTankReference);

	// Properties:

	// Constant Values:
	const float ENEMY_TRANSLATION_MAGNITUDE = 0.020f;
	const int ENEMY_DAMAGE_TO_PLAYER = 10;

private:

	// Functions/methods:

	/** Rotate to face a vector-position. */
	void RotateToFace();

	/** Get a target to move to. */
	void FindTarget(PlayerHoverTank*&
		PlayerHoverTankReference);

	/** Move to the current target. */
	void MoveToTarget();

	// Properties:

	/** For the current state of this tank. */
	AIState CurrentState;

	/** 
		The Enemy's default target is
		the Player's hover-tank. 
	*/
	PlayerHoverTank* CurrentTarget;
};

