#include "WindowClass.h"

#include "GlobalReferences.h"
#include "PlayerHoverTank.h"

// Initialise an instance:
WindowClass::WindowClass()
{

}

// Clean-up an instance:
WindowClass::~WindowClass()
{
	if (InstanceWindowHandle)
	{
		delete InstanceWindowHandle;
		InstanceWindowHandle = nullptr;
	}
}

// Register class and create the window for DirectX to use:
HRESULT WindowClass::InitialiseWindow(HINSTANCE InstanceHandle, int nCmdShow, WNDPROC WindowsProcedure)
{
	// Register class
	WNDCLASSEX wcex = { 0 };
	wcex.cbSize = sizeof(WNDCLASSEX);
	wcex.style = CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc = WindowsProcedure;
	wcex.hInstance = InstanceHandle;
	wcex.hCursor = LoadCursor(NULL, IDC_ARROW);
	//   wcex.hbrBackground = (HBRUSH )( COLOR_WINDOW + 1); // Needed for non-D3D apps
	// const char* used once again:
	wcex.lpszClassName = AUTHOR_NAME.c_str();

	if (!RegisterClassEx(&wcex)) return E_FAIL;

	// Create window
	InstanceHandle = InstanceHandle;

	/**
		1>c:\users\2moraj05\downloads\james-moran-cgp600-ae2-master\windowclass.cpp(41): warning C4838: conversion from 'const FLOAT' to 'LONG' requires a narrowing conversion
		1>c:\users\2moraj05\downloads\james-moran-cgp600-ae2-master\windowclass.cpp(41): warning C4244: 'initializing': conversion from 'const FLOAT' to 'LONG', possible loss of data
	*/

	RECT WindowRectangle = { 0, 0, DEFAULT_WINDOW_WIDTH, DEFAULT_WINDOW_HEIGHT };
	AdjustWindowRect(&WindowRectangle, WS_OVERLAPPEDWINDOW, FALSE);

	// A const char* can be parsed in as an LPCCHAR: 
	WindowHandle = CreateWindow(AUTHOR_NAME.c_str(), WINDOW_TITLE.c_str(), WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT, WindowRectangle.right - WindowRectangle.left,
		WindowRectangle.bottom - WindowRectangle.top, NULL, NULL, InstanceHandle, NULL);
	if (!WindowHandle)
	{
		return E_FAIL;
	}
	ShowWindow(WindowHandle, nCmdShow);

	return S_OK;
}

HRESULT WindowClass::WindowsProcedureLogic(HWND WindowHandle, 
	UINT Message, WPARAM WParam, LPARAM LParam, 
	DirectXSystem*& DirectXSystemHandleReference, 
	PlayerHoverTank*& PlayerHoverTankReference)
{
	PAINTSTRUCT PaintStructure;
	HDC DeviceContextHandle;

	switch (Message)
	{
	case WM_PAINT:
		DeviceContextHandle = BeginPaint(WindowHandle, &PaintStructure);
		EndPaint(WindowHandle, &PaintStructure);
		break;

	case WM_DESTROY:
		PostQuitMessage(0);
		break;

	case WM_KEYDOWN:
		ManageKeyPressed(WParam, PlayerHoverTankReference->
			GetPlayerCameraReference(), PlayerHoverTankReference);
		break;

		// CHECK TO SEE IF THIS IS THE OPTIMAL WAY TO GO ABOUT RESIZING THE BUFFERS!!OGea
	case WM_SIZE:
		DirectXSystemHandleReference->HandleWindowResizing(WindowHandle);
		break;

	default:
		// A break-point was tResultHandleown on the return line, if hWnd is not valid:
		// BREAKPOINT STILL THROWN AT TIMES GESU(GES[HJAD2!
		if (WindowHandle)
		{
			// Return this result for WndProc in Main to handle:
			return E_FAIL;
		}
	}

	return S_OK;
}

HWND& WindowClass::GetWindowHandle()
{
	return WindowHandle;
}

FLOAT WindowClass::GetFOVAspectRatio()
{
	return (FLOAT) (DEFAULT_WINDOW_WIDTH / DEFAULT_WINDOW_HEIGHT);
}

void WindowClass::ManageKeyPressed(int VirtualKeyCode, Camera*& DefaultCameraReference, 
	PlayerHoverTank*& PlayerHoverTankReference)
{
	switch (VirtualKeyCode)
	{
	case VK_ESCAPE:
		DestroyWindow(WindowHandle);
		break;

		/**
			For movement forwards, backwards, upwards
			and downwards, as well as rotation leftwards,
			rightwards, upwards, downwards and rolling.
		*/
	case VK_WKEY:
		PlayerHoverTankReference->MoveForward(TRANSLATION_MAGNITUDE);
		break;

	case VK_AKEY:
		PlayerHoverTankReference->MoveRight(-TRANSLATION_MAGNITUDE);
		break;

	case VK_SKEY:
		PlayerHoverTankReference->MoveForward(-TRANSLATION_MAGNITUDE);
		break;

	case VK_DKEY:
		PlayerHoverTankReference->MoveRight(TRANSLATION_MAGNITUDE);
		break;

	case VK_QKEY:
		PlayerHoverTankReference->Yaw(-ROTATION_MAGNITUDE);
		break;

	case VK_EKEY:
		PlayerHoverTankReference->Yaw(ROTATION_MAGNITUDE);
		break;

	default:
		break;
	}
}
