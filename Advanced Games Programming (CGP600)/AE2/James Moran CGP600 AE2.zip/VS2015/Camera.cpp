#include "Camera.h"

// Initialise:
Camera::Camera()
{
	Position = DEFAULT_POSITION;
	Target = ZERO_FLOAT3;

	SetDistance(DEFAULT_DISTANCE, DEFAULT_MINIMUM_DISTANCE,
		DEFAULT_MAXIMUM_DISTANCE);
	SetRotation(DEFAULT_X_ROTATION, DEFAULT_Y_ROTATION,
		-XM_PIDIV2, XM_PIDIV2);
}

// Clean-up:
Camera::~Camera()
{
	
}

// Set methods:

void Camera::SetDistance(float NewDistance, float NewMinimumDistance, float NewMaximumDistance)
{
	CurrentDistanceToTarget = NewDistance;
	MinimumDistance = NewMinimumDistance;
	MaximumDistance = NewMaximumDistance;

	// Keep CurrentDistanceToTarget within its bounds:
	CurrentDistanceToTarget = ValidateFloatValue(
		CurrentDistanceToTarget, MinimumDistance,
		MaximumDistance);
}

void Camera::SetRotation(float NewX, float NewY, float NewMinimumY, float NewMaximumY)
{
	XRotation = NewX;
	YRotation = NewY;
	MinimumYRotation = NewMinimumY;
	MaximumYRotation = NewMaximumY;

	// Keep YRotation within its bounds:
	YRotation = ValidateFloatValue(YRotation, MinimumYRotation,
		MaximumYRotation);
}

void Camera::SetTarget(XMFLOAT3& NewTarget)
{
	Target = NewTarget;
}

// Get functions:

// For the WorldViewProjection matrix:
XMMATRIX Camera::GetViewMatrix()
{
	XMVECTOR Zoom = XMVectorSet(0.0f, 0.0f, 
		CurrentDistanceToTarget, 1.0f);
	XMMATRIX RotationMatrix = XMMatrixRotationRollPitchYaw(
		XRotation, YRotation, 0.0f);

	Zoom = XMVector3Transform(Zoom, RotationMatrix);

	XMVECTOR PositionVector = XMLoadFloat3(&Position);
	XMVECTOR LookAt = XMLoadFloat3(&Target);

	PositionVector = LookAt + Zoom;
	PositionVector.y += Y_POSITION_OFFSET;
	XMStoreFloat3(&Position, PositionVector);

	XMVECTOR Up = XMVectorSet(0.0f, 1.0f, 0.0f, 1.0f);
	Up = XMVector3Transform(Up, RotationMatrix);

	return XMMatrixLookAtLH(PositionVector, LookAt, Up);
}

// Validation functions:

// For float values:
float Camera::ValidateFloatValue(float Value, float LowerBound, float UpperBound)
{
	if (Value < LowerBound)
	{
		Value = LowerBound;
		return Value;
	}

	if (Value > UpperBound)
	{
		Value = UpperBound;
		return Value;
	}

	return Value;
}
