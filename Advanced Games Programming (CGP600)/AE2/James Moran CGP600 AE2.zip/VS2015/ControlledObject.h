#pragma once
#include "GameObject.h"

/**
	For objects controlled by the Player or AI.
*/

class ControlledObject : public GameObject
{

protected:

	/**
		Default directions (can be changed if 
		required). 
	*/
	XMVECTOR DefaultForwardDirection;
	XMVECTOR DefaultRightDirection;
	XMVECTOR DefaultUpDirection;

	/** 
		This object's directions relative to 
		itself. 
	*/
	XMVECTOR ObjectForwardDirection;
	XMVECTOR ObjectRightDirection;
	XMVECTOR ObjectUpDirection;

	/** 
		The forward direction vector
		from this object's perspective.
	*/
	XMVECTOR ObjectForwardTarget;

	/** 
		For the object's current 
		direction of movement in
		the game-world.
	*/
	XMVECTOR ObjectMovementDirection;

	/**
		To be used in movement (in respects to 
		the orientation). 
	*/
	float MovementLeftRight;
	float MovementForwardBackwards;
	float MovementUpDown;

public:

	/** Standard constructor */
	ControlledObject(ID3D11Device*& NewD3DDeviceReference, ID3D11DeviceContext*&
		NewD3DDeviceContextReference, HRESULT& ResultHandleReference,
		XMFLOAT3& InitialPosition);
	
	/** Standard destructor */
	virtual ~ControlledObject();

	/** 
		Override the Draw method to draw this object,
		given movement.		
	*/
	void Draw(XMMATRIX* View, XMMATRIX* Projection)override;

	// Movement methods:
	/**
		These methods are overrideable,
		to allow the Player's camera to 
		move with the Player's hover-tank.
	*/

	/** Translation using trig. */
	void MoveForward(float DisplacementValue);
	void MoveRight(float DisplacementValue);

	/** 
		When a static-obstacle, or 
		another controlled-object is 
		hit. 
	*/
	void RepelControlledObject(float RepulsionMagnitude);

	// Get methods/functions:

	XMVECTOR& GetObjectMovementDirection();
};

