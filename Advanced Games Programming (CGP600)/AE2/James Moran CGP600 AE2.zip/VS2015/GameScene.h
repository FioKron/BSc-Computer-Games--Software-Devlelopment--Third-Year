#pragma once
#include "GameObject.h"
#include "DirectXSystem.h"
#include "WindowClass.h"

class GameScene
{

public:

	// Functions:
	
	/** Standard constructor. */
	GameScene(std::vector<GameObject*>& NewSceneObjects,
		int NewSceneID, bool SceneIsActive, 
		ID3D11DeviceContext* NewImmediateContextReference);

	/** Standard destructor. */
	~GameScene();

	/** 
		For when this GameScene 
		is to be updated. 
	*/
	HRESULT UpdateGameScene(ID3D11RenderTargetView* BackBufferRenderTargetViewReference,
	IDXGISwapChain* SwapChainReference, ID3D11Buffer*& VertexBufferReference,
	ID3D11DepthStencilView*& ZBufferReference, ID3D11Buffer*& ConstantBuffer0Reference,
	WindowClass*& WindowClassHandleReference, DirectXSystem*& DirectXSystemHandleReference);

	// Get Functions:

	bool GetIsSceneActive();
	bool GetPlayerIsAlive();
	bool GetPlayerHasWon();
	int GetUniqueSceneID();
	XMMATRIX& GetViewMatrix();
	XMMATRIX& GetProjectionMatrix();

private:

	// Functions/methods:

	/** Draw objects to the back-buffer. */
	void DrawObjects(XMMATRIX* View, XMMATRIX* Projection,
		DirectXSystem*& DirectXSystemHandleReference);

	/** Render the frame for certain scenes */
	HRESULT RenderFrame(ID3D11RenderTargetView*
		BackBufferRenderTargetViewReference,
		IDXGISwapChain* SwapChainReference,
		ID3D11Buffer*& VertexBufferReference,
		ID3D11DepthStencilView*& ZBufferReference,
		ID3D11Buffer*& ConstantBuffer0Reference,
		WindowClass*& WindowClassHandleReference,
		DirectXSystem *& DirectXSystemHandleReference);

	/**
		Check for collision between any objects (before
		rendering the frame). 
	*/
	void ManageCollisionChecking();

	/** 
		Manage which object is to move where.
	*/
	bool RepositionGameObject(GameObject*& OffendingObject,
		GameObject*& VictimObject);

	void PushBackControlledObject(GameObject*& OffendingObject,
		GameObject*& VictimObject);

	void PushAwayMoveableObstacle(GameObject*& OffendingObject,
		GameObject*& VictimObject);

	/** Set the transformation for the camera. */
	void SetupCustomWorldViewProjectionMatrix(XMMATRIX& Projection,
		XMMATRIX& World, XMMATRIX& View, const XMVECTOR& NewTranslation,
		const XMMATRIX & NewRotation, WindowClass *& WindowClassHandleReference,
		DirectXSystem *& DirectXSystemHandleReference);

	void UpdateEnemyHoverTanks();

	// Get Functions:

	/** 
		Look through all the game objects to find the 
		Player's hover-tank (the Player).
	*/
	void GetPlayerHoverTankReference();

	/**
		Perform similar actions to the above
		method, to find references to Enemy 
		hover-tanks.
	*/
	void GetEnemyHoverTankReferences();

	// Properties:

	/**
		For refering to the immediate context of the
		device to which, the user can see.
	*/
	ID3D11DeviceContext* ImmediateContextReference;

	/** 
		For when certain members of the 
		PlayerHoverTank are required.
	*/
	PlayerHoverTank* PlayerHoverTankReference;

	/**
		To allow updating of the EnemyHoverTanks.
	*/
	std::vector<EnemyHoverTank*> EnemyHoverTanksReference;

	/** For all the objects in the scene. */
	std::vector<GameObject*> SceneObjects;

	/** The scene's unique ID. */
	int UniqueSceneID;

	/** For the WorldViewProjection matrix: */
	XMMATRIX Projection, World, View;

	// Flags:

	/** For the scene's active state. */
	bool IsSceneActive;
	bool PlayerHasWon;
	bool PlayerIsAlive;

	// Constant values:

	/** The field of view for the camera to use. */
	const FLOAT DEFAULT_FIELD_OF_VIEW = 60.0f; // Angle noted in degrees
	
	/**
		For finding any controllable objects in the 
		SceneObjects (or other checking). 
	*/
	const std::string PLAYER_FILE_PATH = "Assets/PlayerShip.obj";
	const std::string ENEMY_FILE_PATH = "Assets/EnemyHoverTank.obj";
	const std::string STATIC_ROCK_FILE_PATH = "Assets/StaticRock.obj";
	const std::string MOVEABLE_WOODEN_BARREL_FILE_PATH = "Assets/WoodenBarrel.obj";
	const std::string COLLECTABLE_ENERGY_CAPSULE_FILE_PATH = "Assets/EnergyCapsule.obj";
	const std::string GENERIC_SPLASH_SCREEN_FILE_PATH = "Assets/GenericSplashScreen.obj";
};

