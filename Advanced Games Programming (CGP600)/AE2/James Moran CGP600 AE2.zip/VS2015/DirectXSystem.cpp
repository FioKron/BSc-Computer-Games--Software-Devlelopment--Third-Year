#include "DirectXSystem.h"
#include <d3d11.h>
#include <d3dx11.h>
#include <dxerr.h>

#include "WindowClass.h"

// For 'random' positioning of objects:
#include <random>
#include <time.h>
#include <functional>

// Initialise:
DirectXSystem::DirectXSystem()
{
	ConstantBuffer0Values.Initialise();
	CurrentStaticObstaclePosition = STATIC_OBSTACLE_INITIAL_POSITION;
	CurrentMoveableObstaclePosition = MOVEABLE_OBSTACLE_INITIAL_POSITION;
	CurrentCollectableObjectPosition = COLLECTABLE_OBJECT_INITIAL_POSITION;	
}

// Clean-up:
DirectXSystem::~DirectXSystem()
{
	if (BackBufferRenderTargetViewReference)
	{
		BackBufferRenderTargetViewReference->Release();
		BackBufferRenderTargetViewReference = nullptr;
	}
	if (ZBuffer) ZBuffer->Release(); ZBuffer = nullptr;
	if (SwapChainReference) SwapChainReference->Release();
	SwapChainReference = nullptr;
	if (ImmediateContextReference) ImmediateContextReference->Release();
	ImmediateContextReference = nullptr;
	if (PlayerHoverTankTexture) PlayerHoverTankTexture->Release(); PlayerHoverTankTexture = nullptr;
	if (StaticRockTexture) StaticRockTexture->Release(); StaticRockTexture = nullptr;
	if (WoodenBarrelTexture) WoodenBarrelTexture->Release(); WoodenBarrelTexture = nullptr;
	if (PlayerVictorySplashScreenTexture) PlayerVictorySplashScreenTexture->Release();
	PlayerVictorySplashScreenTexture = nullptr;
	if (PlayerLossSplashScreenTexture) PlayerLossSplashScreenTexture->Release();
	PlayerLossSplashScreenTexture = nullptr;
	if (DefaultTextureSampler) DefaultTextureSampler->Release(); DefaultTextureSampler = nullptr;
	if (InputLayout) InputLayout->Release(); InputLayout = nullptr;
	if (VertexShader) VertexShader->Release(); VertexShader = nullptr;
	if (PixelShader) PixelShader->Release(); PixelShader = nullptr;
	if (VertexBuffer) VertexBuffer->Release(); VertexBuffer = nullptr;
	if (IndexBuffer) IndexBuffer->Release(); IndexBuffer = nullptr;
	if (ConstantBuffer0) ConstantBuffer0->Release(); ConstantBuffer0 = nullptr;
	// Report on any objects that are still live (before releasing the device).
	// (Only for debug build solutions):
	ReportLiveObjects();
	if (D3DDeviceReference) D3DDeviceReference->Release();
	D3DDeviceReference = nullptr;
}

// Create D3D device and swap chain
HRESULT DirectXSystem::InitialiseD3D(HWND& WindowHandle)
{
	HRESULT ResultHandle = S_OK;

	RECT WindowRectangle;
	GetClientRect(WindowHandle, &WindowRectangle);
	UINT Width = WindowRectangle.right - WindowRectangle.left;
	UINT Height = WindowRectangle.bottom - WindowRectangle.top;

	UINT CreateDeviceFlags = 0;

#ifdef _DEBUG
	CreateDeviceFlags |= D3D11_CREATE_DEVICE_DEBUG;
#endif

	D3D_DRIVER_TYPE DriverTypes[] =
	{
		D3D_DRIVER_TYPE_HARDWARE, // comment out this line if you need to test D3D 11.0 functionality on hardware that doesn't support it
		D3D_DRIVER_TYPE_WARP, // comment this out also to use reference device
		D3D_DRIVER_TYPE_REFERENCE,
	};
	UINT numDriverTypeReferences = ARRAYSIZE(DriverTypes);

	D3D_FEATURE_LEVEL FeatureLevels[] =
	{
		D3D_FEATURE_LEVEL_11_0,
		D3D_FEATURE_LEVEL_10_1,
		D3D_FEATURE_LEVEL_10_0,
	};
	UINT numFeatureLevels = ARRAYSIZE(FeatureLevels);

	DXGI_SWAP_CHAIN_DESC DefaultSwapChainDescription;
	ZeroMemory(&DefaultSwapChainDescription, sizeof(DefaultSwapChainDescription));
	DefaultSwapChainDescription.BufferCount = 1;
	DefaultSwapChainDescription.BufferDesc.Width = Width;
	DefaultSwapChainDescription.BufferDesc.Height = Height;
	DefaultSwapChainDescription.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
	DefaultSwapChainDescription.BufferDesc.RefreshRate.Numerator = 60;
	DefaultSwapChainDescription.BufferDesc.RefreshRate.Denominator = 1;
	DefaultSwapChainDescription.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
	DefaultSwapChainDescription.OutputWindow = WindowHandle;
	DefaultSwapChainDescription.SampleDesc.Count = 1;
	DefaultSwapChainDescription.SampleDesc.Quality = 0;
	DefaultSwapChainDescription.Windowed = true;

	for (UINT DriverTypeIndex = 0; DriverTypeIndex < numDriverTypeReferences; DriverTypeIndex++)
	{
		DriverTypeReference = DriverTypes[DriverTypeIndex];
		ResultHandle = D3D11CreateDeviceAndSwapChain(nullptr, DriverTypeReference, nullptr,
			CreateDeviceFlags, FeatureLevels, numFeatureLevels,
			D3D11_SDK_VERSION, &DefaultSwapChainDescription, &SwapChainReference,
			&D3DDeviceReference, &FeatureLevelReference, &ImmediateContextReference);
		if (SUCCEEDED(ResultHandle))
			break;
	}
	
	if (FAILED(ResultHandle))
		return ResultHandle;

	// Get pointer to back buffer texture
	ID3D11Texture2D *pBackBufferTexture;
	ResultHandle = SwapChainReference->GetBuffer(0, __uuidof(ID3D11Texture2D),
		(LPVOID*)&pBackBufferTexture);

	if (FAILED(ResultHandle)) return ResultHandle;

	// Use the back buffer texture pointer to create the render target view
	ResultHandle = D3DDeviceReference->CreateRenderTargetView(pBackBufferTexture, NULL,
		&BackBufferRenderTargetViewReference);
	pBackBufferTexture->Release();

	if (FAILED(ResultHandle)) return ResultHandle;

	// 'Create a Z buffer texture'
	D3D11_TEXTURE2D_DESC ZBufferDescription;
	ZeroMemory(&ZBufferDescription, sizeof(ZBufferDescription));

	ZBufferDescription.Width = Width;
	ZBufferDescription.Height = Height;
	ZBufferDescription.ArraySize = 1;
	ZBufferDescription.MipLevels = 1;
	ZBufferDescription.Format = DXGI_FORMAT_D24_UNORM_S8_UINT;
	ZBufferDescription.SampleDesc.Count = 1;
	ZBufferDescription.BindFlags = D3D11_BIND_DEPTH_STENCIL;
	ZBufferDescription.Usage = D3D11_USAGE_DEFAULT;

	ID3D11Texture2D* ZBufferTexture = nullptr;
	ResultHandle = D3DDeviceReference->CreateTexture2D(&ZBufferDescription, NULL, &ZBufferTexture);

	if (FAILED(ResultHandle))
	{
		return ResultHandle;
	}

	// 'Create the Z buffer'
	D3D11_DEPTH_STENCIL_VIEW_DESC DepthStencilViewDescription;
	ZeroMemory(&DepthStencilViewDescription, sizeof(DepthStencilViewDescription));

	DepthStencilViewDescription.Format = ZBufferDescription.Format;
	DepthStencilViewDescription.ViewDimension = D3D11_DSV_DIMENSION_TEXTURE2D;

	D3DDeviceReference->CreateDepthStencilView(ZBufferTexture, &DepthStencilViewDescription,
		&ZBuffer);

	// No longer required:
	ZBufferTexture->Release();

	// Set the render target view
	ImmediateContextReference->OMSetRenderTargets(1, &BackBufferRenderTargetViewReference, ZBuffer);

	// Set the viewport
	D3D11_VIEWPORT Viewport;

	Viewport.TopLeftX = 0;
	Viewport.TopLeftY = 0;
	Viewport.Width = (FLOAT) Width;
	Viewport.Height = (FLOAT) Height;
	/**
	It seems as though the window is created in a diffrent on-screen location
	(changing between 0 and the current value):
	*/
	Viewport.MinDepth = 0.0f; // For Tutorial 06 Extra 01 (Now changed back to zero)
	Viewport.MaxDepth = 1.0f;

	ImmediateContextReference->RSSetViewports(1, &Viewport);

	return S_OK;
}

// Initialise graphics:
HRESULT DirectXSystem::InitialiseGraphics(PlayerHoverTank*&
	PlayerHoverTankReference,
	NonControlledSceneObjects*&
	Scene0ObjectsReference, 
	std::vector<EnemyHoverTank*>&
	EnemyHoverTanksReference)//'03-01'
{
	HRESULT ResultHandle = S_OK;

	// Set-up the Player's hover-tank:
	PlayerHoverTankReference = new PlayerHoverTank(D3DDeviceReference, ImmediateContextReference,
		ResultHandle, DEFAULT_PLAYER_MODEL_LOCATION);

	if (PlayerHoverTankReference)
	{
		ResultHandle = PlayerHoverTankReference->
			LoadObjectModel(DEFAULT_PLAYER_MODEL_FILE_PATH);

		if (FAILED(ResultHandle))
		{
			return ResultHandle;
		}
	}

	// Set-up the Enemy hover-tanks as well:
	for (int Iterator = 0; Iterator < ENEMY_HOVER_TANK_QUANTITY;
		Iterator++)
	{
		EnemyHoverTanksReference.push_back(new EnemyHoverTank(D3DDeviceReference,
			ImmediateContextReference, ResultHandle, 
			DEFAULT_FIRST_ENEMY_HOVER_TANK_LOCATION));

		if (EnemyHoverTanksReference[Iterator])
		{
			ResultHandle = EnemyHoverTanksReference[Iterator]->
				LoadObjectModel(DEFAULT_ENEMY_MODEL_FILE_PATH);

			if (FAILED(ResultHandle))
			{
				return ResultHandle;
			}
		}
	}

	// Set-up the scene's non-controlled objects:
	Scene0ObjectsReference = new NonControlledSceneObjects(SCENE0_STATIC_OBSTACLE_COUNT,
		SCENE0_MOVEABLE_OBSTACLE_COUNT, SCENE0_COLLECTABLE_OBJECT_COUNT);
	
	if (FAILED(InitialiseStaticObstacles(Scene0ObjectsReference,
		ResultHandle)))
	{
		return ResultHandle;
	}

	if (FAILED(InitialiseMoveableObstacles(Scene0ObjectsReference,
		ResultHandle)))
	{
		return ResultHandle;
	}

	if (FAILED(InitialiseCollectableObjects(Scene0ObjectsReference,
		ResultHandle)))
	{
		return ResultHandle;
	}

	// Initialise all the textures:
	InitialiseTexture(DEFAULT_PLAYER_MODEL_TEXTURE_FILE_PATH, PlayerHoverTankTexture);
	InitialiseTexture(DEFAULT_STATIC_ROCK_TEXTURE_FILE_PATH, StaticRockTexture);
	InitialiseTexture(DEFAULT_WOODEN_BARREL_TEXTURE_FILE_PATH, WoodenBarrelTexture);
	InitialiseTexture(DEFAULT_ENERGY_CAPSULE_TEXTURE_FILE_PATH, EnergyCapsuleTexture);
	InitialiseTexture(DEFAULT_ENEMY_MODEL_TEXTURE_FILE_PATH, EnemyHoverTankTexture);
	InitialiseTexture(PLAYER_VICTORY_SPLASH_SCREEN_TEXTURE_FILE_PATH, 
		PlayerVictorySplashScreenTexture);
	InitialiseTexture(PLAYER_LOSS_SPLASH_SCREEN_TEXTURE_FILE_PATH,
		PlayerLossSplashScreenTexture);

	// Create the second constant buffer:
	D3D11_BUFFER_DESC Constant_Buffer0_Description;
	ZeroMemory(&Constant_Buffer0_Description, sizeof(Constant_Buffer0_Description));
	Constant_Buffer0_Description.Usage = D3D11_USAGE_DEFAULT; // 'Can use UpdateSubresource() to update'
	Constant_Buffer0_Description.ByteWidth = FIRST_CONSTANT_BUFFER_BYTE_WIDTH; // 'MUST be a multiple of 16, calculate from CB struct'
	Constant_Buffer0_Description.BindFlags = D3D11_BIND_CONSTANT_BUFFER; // 'Use as a constant buffer'

	ResultHandle = D3DDeviceReference->CreateBuffer(&Constant_Buffer0_Description, NULL, &ConstantBuffer0);

	if (FAILED(ResultHandle))
	{
		return ResultHandle;
	}

	// 'Set up and create vertex buffer'
	D3D11_BUFFER_DESC VertexBufferDescription;
	ZeroMemory(&VertexBufferDescription, sizeof(VertexBufferDescription));
	VertexBufferDescription.Usage = D3D11_USAGE_DYNAMIC; // 'Used by CPU and GPU'
	VertexBufferDescription.ByteWidth = sizeof(POS_COL_TEX_NORM_VERTEX) * VERTEX_COUNT; // Total size of buffer, VERTEX_COUNT vertices 
	VertexBufferDescription.BindFlags = D3D11_BIND_VERTEX_BUFFER; // 'Use as a vertex buffer'
	VertexBufferDescription.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE; // 'Allow CPU access'

	ResultHandle = D3DDeviceReference->CreateBuffer(&VertexBufferDescription, nullptr, &VertexBuffer); // 'Create the buffer'

	if (FAILED(ResultHandle)) // return error code on failure
	{
		return ResultHandle;
	}

	if (FAILED(SetUpShaders(ResultHandle)))
	{
		return ResultHandle;
	}

	D3D11_SAMPLER_DESC DefaultTextureSamplerDescription;
	ZeroMemory(&DefaultTextureSamplerDescription, sizeof(DefaultTextureSamplerDescription));
	DefaultTextureSamplerDescription.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
	DefaultTextureSamplerDescription.AddressU = D3D11_TEXTURE_ADDRESS_WRAP;
	DefaultTextureSamplerDescription.AddressV = D3D11_TEXTURE_ADDRESS_WRAP;
	DefaultTextureSamplerDescription.AddressW = D3D11_TEXTURE_ADDRESS_WRAP;
	DefaultTextureSamplerDescription.MaxLOD = D3D11_FLOAT32_MAX;

	D3DDeviceReference->CreateSamplerState(&DefaultTextureSamplerDescription, &DefaultTextureSampler);
	
	/** 
		To resolve:
		D3D11 ERROR: ID3D11DeviceContext::Draw: Current Primitive Topology value (0) 
		is not valid. [EXECUTION ERROR #365: DEVICE_DRAW_INVALID_PRIMITIVETOPOLOGY]

		USE D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST HERE, NOT TRIANGLESTRIP!!DA:wA
	*/
	ImmediateContextReference->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

	return S_OK;
}

// Initialiser functions:

HRESULT DirectXSystem::InitialiseStaticObstacles(NonControlledSceneObjects*& Scene0ObjectsReference, 
	HRESULT& ResultHandleReference)
{
	int CollectionIterator = 0;

	// Only to the limit:
	for (CollectionIterator; CollectionIterator < SCENE0_STATIC_OBSTACLE_COUNT;
		CollectionIterator++)
	{
		Scene0ObjectsReference->StaticObstaclesReference.push_back(
			new StaticObstacle(D3DDeviceReference, ImmediateContextReference,
				ResultHandleReference, CurrentStaticObstaclePosition));
		// Positioning the objects in lines for now:
		CurrentStaticObstaclePosition.x += DEFAULT_POSITION_INCREMENTOR.x;

		if (Scene0ObjectsReference->
			StaticObstaclesReference[CollectionIterator])
		{
			ResultHandleReference = Scene0ObjectsReference->
				StaticObstaclesReference[CollectionIterator]
				->LoadObjectModel(DEFAULT_STATIC_OBSTACLE_FILE_PATH);

			if (FAILED(ResultHandleReference))
			{
				return ResultHandleReference;
			}
		}
	}

	return ResultHandleReference;
}

HRESULT DirectXSystem::InitialiseMoveableObstacles(NonControlledSceneObjects*& Scene0ObjectsReference,
	HRESULT& ResultHandleReference)
{
	int CollectionIterator = 0;

	// Only to the limit:
	for (CollectionIterator; CollectionIterator < SCENE0_MOVEABLE_OBSTACLE_COUNT;
		CollectionIterator++)
	{
		Scene0ObjectsReference->MoveableObstaclesReference.push_back(
			new MoveableObstacle(D3DDeviceReference, ImmediateContextReference,
				ResultHandleReference, CurrentMoveableObstaclePosition));
		CurrentMoveableObstaclePosition.x += DEFAULT_POSITION_INCREMENTOR.x;

		if (Scene0ObjectsReference->
			MoveableObstaclesReference[CollectionIterator])
		{
			ResultHandleReference = Scene0ObjectsReference->
				MoveableObstaclesReference[CollectionIterator]
				->LoadObjectModel(DEFAULT_MOVEABLE_OBSTACLE_FILE_PATH);

			if (FAILED(ResultHandleReference))
			{
				return ResultHandleReference;
			}
		}
	}

	return ResultHandleReference;
}

HRESULT DirectXSystem::InitialiseCollectableObjects(NonControlledSceneObjects*& Scene0ObjectsReference,
	HRESULT& ResultHandleReference)
{
	int CollectionIterator = 0;

	// Only to the limit:
	for (CollectionIterator; CollectionIterator < SCENE0_COLLECTABLE_OBJECT_COUNT;
		CollectionIterator++)
	{
		Scene0ObjectsReference->CollectableObjectsReference.push_back(
			new CollectableObject(D3DDeviceReference, ImmediateContextReference,
				ResultHandleReference, CurrentCollectableObjectPosition));
		CurrentCollectableObjectPosition.x += DEFAULT_POSITION_INCREMENTOR.x;

		if (Scene0ObjectsReference->
			CollectableObjectsReference[CollectionIterator])
		{
			ResultHandleReference = Scene0ObjectsReference->
				CollectableObjectsReference[CollectionIterator]
				->LoadObjectModel(DEFAULT_COLLECTABLE_OBJECT_FILE_PATH);

			if (FAILED(ResultHandleReference))
			{
				return ResultHandleReference;
			}
		}
	}

	return ResultHandleReference;
}

// Given a file-path and a ID3D11ShaderResourceView reference...
void DirectXSystem::InitialiseTexture(std::string TextureFilePath, ID3D11ShaderResourceView *& TextureReference)
{
	D3DX11CreateShaderResourceViewFromFile(D3DDeviceReference,
		TextureFilePath.c_str(), NULL,
		NULL, &TextureReference, NULL);
}

// Initialise the shaders:
HRESULT DirectXSystem::SetUpShaders(HRESULT ResultHandle)
{
	// 'Load and compile pixel and vertex shaders - use vs_5_0 to target DX11 hardware only'
	ID3DBlob *VertexShaderBlob, *PixelShaderBlob, *Error;
	ResultHandle = D3DX11CompileFromFile("shaders.hlsl", 0, 0, "VShader", "vs_4_0", 0, 0, 0, 
		&VertexShaderBlob, &Error, 0);
	
	if (Error != 0) // 'check for shader compilation error'
	{
		OutputDebugStringA((char*)Error->GetBufferPointer());
		Error->Release();
		if (FAILED(ResultHandle)) // 'don't fail is error is just a warning'
		{
			return ResultHandle;
		};
	}

	ResultHandle = D3DX11CompileFromFile("shaders.hlsl", 0, 0, "PShader", "ps_4_0", 0, 0, 0,
		&PixelShaderBlob, &Error, 0);

	if (Error != 0) // 'check for shader compilation error'
	{
		OutputDebugStringA((char*)Error->GetBufferPointer());
		Error->Release();
		if (FAILED(ResultHandle)) // 'don't fail is error is just a warning'
		{
			return ResultHandle;
		};
	}

	// 'Create shader objects'
	ResultHandle = D3DDeviceReference->CreateVertexShader(VertexShaderBlob->GetBufferPointer(),
		VertexShaderBlob->GetBufferSize(), NULL, &VertexShader);

	if (FAILED(ResultHandle))
	{
		return ResultHandle;
	}

	ResultHandle = D3DDeviceReference->CreatePixelShader(PixelShaderBlob->GetBufferPointer(),
		PixelShaderBlob->GetBufferSize(), NULL, &PixelShader);

	if (FAILED(ResultHandle))
	{
		return ResultHandle;
	}

	// 'Set the shader objects as active'
	ImmediateContextReference->VSSetShader(VertexShader, 0, 0);
	ImmediateContextReference->PSSetShader(PixelShader, 0, 0);

	// 'Create and set the input layout object'
	D3D11_INPUT_ELEMENT_DESC iedesc[] =
	{
		{ "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0, D3D11_INPUT_PER_VERTEX_DATA, 0 },
		{ "COLOR", 0, DXGI_FORMAT_R32G32B32A32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0},
		{ "TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0},
		{ "NORMAL", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0}
	};

	ResultHandle = D3DDeviceReference->CreateInputLayout(iedesc, ARRAYSIZE(iedesc), VertexShaderBlob->GetBufferPointer(),
		VertexShaderBlob->GetBufferSize(), &InputLayout);

	if (FAILED(ResultHandle))
	{
		return ResultHandle;
	}

	ImmediateContextReference->IASetInputLayout(InputLayout);

	/**
		Removed due to a breakpoint sometimes getting triggered here.
	*/

	// Clean up the local pointers:
	//if (VertexShaderBlob) VertexShaderBlob->Release(); VertexShaderBlob = nullptr;
	//if (PixelShaderBlob) PixelShaderBlob->Release(); PixelShaderBlob = nullptr;
	//if (Error) Error->Release(); Error = nullptr;

	return ResultHandle;
}

// Report on live objects:
void DirectXSystem::ReportLiveObjects()
{
	// Only if this is a debug build:
#ifdef _DEBUG
	ID3D11Debug* DebugDevice = nullptr;
	HRESULT ResultHandle = D3DDeviceReference->QueryInterface(__uuidof(ID3D11Debug),
		reinterpret_cast<void**>(&DebugDevice));
	if (FAILED(ResultHandle))
	{
		return;
	}

	ResultHandle = DebugDevice->ReportLiveDeviceObjects(D3D11_RLDO_DETAIL);
	if (FAILED(ResultHandle))
	{
		return;
	}

	if (DebugDevice)
	{
		DebugDevice->Release();
	}
#endif
}

// Get the new 'random' position incrementor,
// to add on, for the new position of an object
// (in the XZ plane):
XMFLOAT3 DirectXSystem::GetNewObjectPosition()
{
	std::default_random_engine Generator;
	std::uniform_int_distribution<int> UniformDistribution(MINIMUM_XZ_POSITION,
		MAXIMUM_XZ_POSITION);
	
	// Seed the generator before binding:	
	Generator.seed((unsigned int) time(nullptr));

	// Bound together for repeated uses:
	// auto used here to skip having to set-up std::_Binder:
	auto GetRandomInteger = std::bind(UniformDistribution, Generator);

	return XMFLOAT3((float) GetRandomInteger(), 0.0f, (float) GetRandomInteger());
}

HRESULT DirectXSystem::HandleWindowResizing(HWND& WindowHandle)
{
	// The default value to return (if SwapChainReference is invalid):
	const HRESULT SWAP_CHAIN_REFERENCE_INVALID = HRESULT_FROM_WIN32(ERROR_NOT_FOUND);
	
	// For checking the results of functions:
	HRESULT ErrorResultHandle = SWAP_CHAIN_REFERENCE_INVALID; 

	if (SwapChainReference)
	{
		/**
			Solution found at:
			https://msdn.microsoft.com/en-us/library/windows/desktop/bb205075(v=vs.85).aspx#Handling_Window_Resizing
		*/

		/**
			This result has been set to S_OK in execution so far
			(when calling ResizeBuffers):
		*/

		ImmediateContextReference->OMSetRenderTargets(0, 0, 0);

		// Release all outstanding references to the swap chain's buffers:
		BackBufferRenderTargetViewReference->Release();

		/**
			Then it is possible to resize the buffers correctly
			(Using DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH for the
			last parameter to allowing switching between full-screen
			and windowed mode. I'm also using DXGI_FORMAT_UNKNOWN, to
			preserve the existing format. Finally, I have set the first 3
			parameters as 0, to preserve the exitsting number of buffers,
			as well as having DXGI use the Width and Height of the client
			area of the target window, for then new Width and Height).

			SOURCE: https://msdn.microsoft.com/en-us/library/bb174577(v=vs.85).aspx
		*/
		ErrorResultHandle = SwapChainReference->ResizeBuffers(0, 0, 0, DXGI_FORMAT_UNKNOWN,
			DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH);

		if (ErrorResultHandle != S_OK)
		{
			return ErrorResultHandle;
		}

		// Get buffer and create a render-target-view.
		ID3D11Texture2D* pBuffer;
		ErrorResultHandle = SwapChainReference->GetBuffer(0, __uuidof(ID3D11Texture2D),
			(void**)&pBuffer);

		if (ErrorResultHandle != S_OK)
		{
			return ErrorResultHandle;
		}

		ErrorResultHandle = D3DDeviceReference->CreateRenderTargetView(pBuffer, NULL,
			&BackBufferRenderTargetViewReference);

		if (ErrorResultHandle != S_OK)
		{
			return ErrorResultHandle;
		}

		pBuffer->Release();

		ImmediateContextReference->OMSetRenderTargets(1, &BackBufferRenderTargetViewReference, NULL);

		// Get the new bounds of the window:
		RECT ClientBounds;
		GetClientRect(WindowHandle, &ClientBounds);
		FLOAT NewWidth = (FLOAT) (ClientBounds.right - ClientBounds.left);
		FLOAT NewHeight = (FLOAT) (ClientBounds.bottom - ClientBounds.top);

		// Set up the viewport.
		D3D11_VIEWPORT NewViewport;
		NewViewport.Width = NewWidth;
		NewViewport.Height = NewHeight;
		NewViewport.MinDepth = 0.0f;
		NewViewport.MaxDepth = 1.0f;
		NewViewport.TopLeftX = 0;
		NewViewport.TopLeftY = 0;
		ImmediateContextReference->RSSetViewports(1, &NewViewport);
	}

	return ErrorResultHandle;
}

// Get method implementation:

ID3D11DeviceContext*& DirectXSystem::GetImmediateContextReference()
{
	return ImmediateContextReference;
}

IDXGISwapChain*& DirectXSystem::GetSwapChainReference()
{
	return SwapChainReference;
}

ID3D11RenderTargetView*& DirectXSystem::GetBackBufferRenderTargetViewReference()
{
	return BackBufferRenderTargetViewReference;
}

// The SceneManager will call this function:
void DirectXSystem::UpdateConstantBuffer(XMMATRIX& Projection, XMMATRIX& World, 
	XMMATRIX& View, XMVECTOR& DirectionalLightVector,
	XMVECTOR& DirectionalLightColour, XMVECTOR& AmbientLightColour)
{
	// For lighting:
	XMMATRIX TransposeMatrix = XMMATRIX();

	// Keep in mind the transformation order: Scale, Rotation, Translation:
	ConstantBuffer0Values.WorldViewProjectionMatrix = World * View * Projection;

	// Update the light properties now:
	TransposeMatrix = XMMatrixTranspose(World);
	
	ConstantBuffer0Values.DirectionalLightColour = DirectionalLightColour;
	ConstantBuffer0Values.AmbientLightColour = AmbientLightColour;
	ConstantBuffer0Values.DirectionalLightVector = XMVector3Transform(DirectionalLightVector,
		TransposeMatrix);
	ConstantBuffer0Values.DirectionalLightVector = XMVector3Normalize(
		ConstantBuffer0Values.DirectionalLightVector);
	ImmediateContextReference->UpdateSubresource(ConstantBuffer0, 0u, 0u, &ConstantBuffer0Values, 0u, 0u);
}

// Get Functions:

ID3D11Buffer*& DirectXSystem::GetConstantBuffer0Reference()
{
	return ConstantBuffer0;
}

ID3D11Buffer*& DirectXSystem::GetVertexBufferReference()
{
	return VertexBuffer;
}

ID3D11Buffer*& DirectXSystem::GetIndexBufferReference()
{
	return IndexBuffer;
}

ID3D11DepthStencilView*& DirectXSystem::GetZBufferReference()
{
	return ZBuffer;
}

ID3D11ShaderResourceView*& DirectXSystem::GetPlayerHoverTankTextureReference()
{
	return PlayerHoverTankTexture;
}

ID3D11ShaderResourceView*& DirectXSystem::GetStaticRockTextureReference()
{
	return StaticRockTexture;
}

ID3D11ShaderResourceView*& DirectXSystem::GetWoodenBarrelTextureReference()
{
	return WoodenBarrelTexture;
}

ID3D11ShaderResourceView*& DirectXSystem::GetEnergyCapsuleTextureReference()
{
	return EnergyCapsuleTexture;
}

ID3D11ShaderResourceView*& DirectXSystem::GetEnemyHoverTankTextureReference()
{
	return EnemyHoverTankTexture;
}

ID3D11ShaderResourceView*& DirectXSystem::GetPlayerLossSplashScreenTexture()
{
	return PlayerLossSplashScreenTexture;
}

ID3D11ShaderResourceView*& DirectXSystem::GetPlayerVictorySplashScreenTexture()
{
	return PlayerVictorySplashScreenTexture;
}

ID3D11SamplerState*& DirectXSystem::GetDefaultTextureSamplerReference()
{
	return DefaultTextureSampler;
}

ID3D11Device*& DirectXSystem::GetD3DDeviceReference()
{
	return D3DDeviceReference;
}
