#pragma once
#include "GameObject.h"

class MoveableObstacle : public GameObject
{

public:

	/** Standard constructor. */
	MoveableObstacle(ID3D11Device*& NewD3DDeviceReference, ID3D11DeviceContext*&
		NewD3DDeviceContextReference, HRESULT& ResultHandleReference,
		XMFLOAT3& InitialPosition);
	
	/** Standard destructor. */
	~MoveableObstacle();

	/** If ever an impact occurs with this obstacle. */
	void OnImpact(XMVECTOR& ImpactDirection);

	// Properties:

	// Constant values:

	const float PUSH_FORCE_MAGNITUDE = 10.0f;
};

