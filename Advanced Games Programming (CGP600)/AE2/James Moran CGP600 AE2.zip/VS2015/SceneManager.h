#pragma once
#include <Windows.h>
#include <windows.h>
#include <d3d11.h>
#include <d3dx11.h>
#include <dxerr.h>

#include "WindowClass.h"
#include "Camera.h"
#include "GlobalReferences.h"
#include "GameScene.h"

#define _XM_NO_INTRINSICS_
#define XM_NO_ALIGNMENT
#include <xnamath.h>

class SceneManager
{

public:

	// Structures:

	/** To refer to any GameScene */
	struct SceneComponents
	{
		/** 
			Initialise this member of this structure
			before it is used. 
		*/
		std::vector<GameObject*>& SceneObjects = std::vector<GameObject*>();
		int SceneID;
		bool SceneIsActive;

		SceneComponents::SceneComponents(std::vector<GameObject*>&
			NewSceneObjects, int NewSceneID, bool SceneActive)
		{
			SceneObjects = NewSceneObjects;
			SceneID = NewSceneID;
			SceneIsActive = SceneActive;
		}
	};

	// Functions:

	/** Standard constructor */
	SceneManager(ID3D11DeviceContext* NewImmediateContextReference,
		std::vector<SceneComponents*>& NewGameSceneValues);

	/** Standard destructor */
	~SceneManager();

	/** Update the active scene(s) in the game. */
	HRESULT UpdateGameScenes(ID3D11RenderTargetView* BackBufferRenderTargetViewReference,
		IDXGISwapChain* SwapChainReference, ID3D11Buffer*& VertexBufferReference,
		ID3D11DepthStencilView*& ZBufferReference, ID3D11Buffer*& ConstantBuffer0Reference,
		WindowClass*& WindowClassHandleReference, DirectXSystem*& DirectXSystemHandleReference);

	// Get functions:

	// To check on its values:
	GameScene*& GetDefaultGameScene();

private:

	/** 
		To store all the game scenes of the game 
		(whether they are active or not).
	*/
	std::vector<GameScene*> GameScenes;

	// Constant values:

	const UINT FIRST_CONSTANT_BUFFER_BYTE_WIDTH = 144;

	/** For the constant buffer used in the vertex shader. */
	const UINT VERTEX_SHADER_BUFFER_COUNT = 1;
};

