#pragma once
#include <Windows.h>
#include <windows.h>
#include <string>

#include "Camera.h"
#include "DirectXSystem.h"

/**
	Class name: WindowClass.

	Purpose: To encapsulate the functionality
	of window creation (for a win32 application),
	in order to a show a window that DirectX can
	use.
*/

class WindowClass
{

private:

	// Properties:

	HINSTANCE InstanceWindowHandle = nullptr;
	HWND WindowHandle;

	// Constant values:

	/**
		The window's title (left as my name plus
		the unit and assignment for now).
	*/
	const std::string WINDOW_TITLE = "James Moran CGP600 AE2\0";

	/**
		The author's name (me, James Moran).
	*/
	const std::string AUTHOR_NAME = "James Moran\0";

	/** 
		For the window's extents. (Changed from FLOAT to LONG 
		given narrowing conversion other-wise being required,
		as well as possible loss of data).
	*/
	const LONG DEFAULT_WINDOW_WIDTH = 800L; // Pixels
	const LONG DEFAULT_WINDOW_HEIGHT = 600L; // Pixels
	
	/** For the all transformation functions (scale, rotation and translation) */
	const float TRANSLATION_MAGNITUDE = 5.0f;
	const float ROTATION_MAGNITUDE = 45.0f;

	// Functions:
	
	/**
		Handle the action(s) taken when certain keys are pressed
		(This function would not account shift or ctrl pressed
		whilst another key is being pressed):
	*/
	void ManageKeyPressed(int VirtualKeyCode, Camera*& DefaultCameraReference,
		PlayerHoverTank*& PlayerHoverTankReference);

public:

	// Functions/Methods:

	/** Standard constructor. */
	WindowClass();

	/** Standard destructor. */
	~WindowClass();

	/** 
		Initialise the window for DirectX to use (as well
		as registering the class). 
	*/
	HRESULT InitialiseWindow(HINSTANCE InstanceHandle, int nCmdShow, WNDPROC WindowsProcedure);

	/** 
		Called in Main.cpp, to handle WndProc behavior 
		(W used to equate to 'word' and L used to equate
		to 'long', but this is not the case in x64. This 
		was how they were initially defined in 16-bit 
		windows). 
	*/
	HRESULT WindowsProcedureLogic(HWND WindowHandle, UINT Message, WPARAM WParam,
		LPARAM LParam, DirectXSystem*& DirectXSystemHandleReference,
		PlayerHoverTank*& PlayerHoverTankReference);

	// Get Functions:
	HWND& GetWindowHandle();
	FLOAT GetFOVAspectRatio();
};

