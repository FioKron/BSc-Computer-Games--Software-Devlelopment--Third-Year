#include "GameScene.h"
#include "MoveableObstacle.h"
#include <algorithm>

// Initialise:
GameScene::GameScene(std::vector<GameObject*>& NewSceneObjects,
	int NewSceneID, bool SceneIsActive,
	ID3D11DeviceContext* NewImmediateContextReference)
{
	SceneObjects = NewSceneObjects;
	UniqueSceneID = NewSceneID;
	IsSceneActive = SceneIsActive;
	ImmediateContextReference = NewImmediateContextReference;
	PlayerHasWon = false;
	PlayerIsAlive = true;
}

// Clean-up:
GameScene::~GameScene()
{
	
}

// Update this scene:
HRESULT GameScene::UpdateGameScene(ID3D11RenderTargetView* BackBufferRenderTargetViewReference,
	IDXGISwapChain* SwapChainReference, ID3D11Buffer*& VertexBufferReference,
	ID3D11DepthStencilView*& ZBufferReference, 
	ID3D11Buffer*& ConstantBuffer0Reference,
	WindowClass*& WindowClassHandleReference, 
	DirectXSystem*& DirectXSystemHandleReference)
{
	ManageCollisionChecking();

	HRESULT ResultHandle = RenderFrame(
		BackBufferRenderTargetViewReference,
		SwapChainReference, VertexBufferReference, 
		ZBufferReference,
		ConstantBuffer0Reference, WindowClassHandleReference,
		DirectXSystemHandleReference);

	if (FAILED(ResultHandle))
	{
		return ResultHandle;
	}

	return ResultHandle;
}

bool GameScene::GetIsSceneActive()
{
	return IsSceneActive;
}

bool GameScene::GetPlayerIsAlive()
{
	return PlayerIsAlive;
}

bool GameScene::GetPlayerHasWon()
{
	return PlayerHasWon;
}

int GameScene::GetUniqueSceneID()
{
	return UniqueSceneID;
}

XMMATRIX& GameScene::GetViewMatrix()
{
	return View;
}

XMMATRIX& GameScene::GetProjectionMatrix()
{
	return Projection;
}

void GameScene::DrawObjects(XMMATRIX* View, XMMATRIX* Projection,
	DirectXSystem*& DirectXSystemHandleReference)
{
	HRESULT ResultHandle = S_OK;

	for each (GameObject* CurrentObject in SceneObjects)
	{
		// Check what GameObject CurrentObject is...
		if (CurrentObject->GetObjectModelFileName() ==
			PLAYER_FILE_PATH)
		{
			ImmediateContextReference->PSSetShaderResources(0, 1, &DirectXSystemHandleReference
				->GetPlayerHoverTankTextureReference());
		}

		if (CurrentObject->GetObjectModelFileName() ==
			STATIC_ROCK_FILE_PATH)
		{
			ImmediateContextReference->PSSetShaderResources(0, 1, &DirectXSystemHandleReference
				->GetStaticRockTextureReference());
		}

		if (CurrentObject->GetObjectModelFileName() ==
			MOVEABLE_WOODEN_BARREL_FILE_PATH)
		{
			ImmediateContextReference->PSSetShaderResources(0, 1, &DirectXSystemHandleReference
				->GetWoodenBarrelTextureReference());
		}

		if (CurrentObject->GetObjectModelFileName() ==
			COLLECTABLE_ENERGY_CAPSULE_FILE_PATH)
		{
			ImmediateContextReference->PSSetShaderResources(0, 1, &DirectXSystemHandleReference->
				GetEnergyCapsuleTextureReference());
		}

		if (CurrentObject->GetObjectModelFileName() ==
			ENEMY_FILE_PATH)
		{
			ImmediateContextReference->PSSetShaderResources(0, 1, &DirectXSystemHandleReference->
				GetEnemyHoverTankTextureReference());
		}	

		if (!PlayerHoverTankReference->GetPlayerIsAlive())
		{
			PlayerIsAlive = false;
		}

		if (PlayerHoverTankReference->GetPlayerHasWon())
		{
			PlayerHasWon = true;
		}

		// ...before drawing it:
		CurrentObject->Draw(View, Projection);
	}
}

HRESULT GameScene::RenderFrame(ID3D11RenderTargetView*
	BackBufferRenderTargetViewReference, 
	IDXGISwapChain* SwapChainReference, 
	ID3D11Buffer*& VertexBufferReference, 
	ID3D11DepthStencilView*& ZBufferReference, 
	ID3D11Buffer*& ConstantBuffer0Reference, 
	WindowClass*& WindowClassHandleReference, 
	DirectXSystem*& DirectXSystemHandleReference)
{
	HRESULT ResultHandle = S_OK;

	if (!PlayerHoverTankReference)
	{
		GetPlayerHoverTankReference();
	}

	if (EnemyHoverTanksReference.size() ==
		0u)
	{
		GetEnemyHoverTankReferences();
	}

	UpdateEnemyHoverTanks();

	ImmediateContextReference = DirectXSystemHandleReference->GetImmediateContextReference();

	if (BackBufferRenderTargetViewReference && ImmediateContextReference)
	{
		ImmediateContextReference->ClearRenderTargetView(BackBufferRenderTargetViewReference, DirectXSystemHandleReference->DEFAULT_CLEAR_COLOUR);
	}

	// 'Set the render target view'
	ImmediateContextReference->ClearDepthStencilView(ZBufferReference, D3D11_CLEAR_DEPTH | D3D11_CLEAR_STENCIL, 1.0f, 0);

	ImmediateContextReference->PSSetSamplers(0, 1, &DirectXSystemHandleReference->GetDefaultTextureSamplerReference());

	XMMATRIX CameraRotationMatrix = XMMATRIX();
	SetupCustomWorldViewProjectionMatrix(Projection, World, View,
		PlayerHoverTankReference->GetVectorPosition(), CameraRotationMatrix,
		WindowClassHandleReference, DirectXSystemHandleReference);

	DrawObjects(&View, &Projection, DirectXSystemHandleReference);

	// Display what has just been rendered
	SwapChainReference->Present(0, 0);

	return ResultHandle;
}

/**
	NOTE: Resolved issues with collision by using dynamic_cast,
	instead of static_cast (to get the right type of obstacle).
*/

// Check to see if any objects are colliding:
void GameScene::ManageCollisionChecking()
{
	for (UINT ObjectIterator = 0u; ObjectIterator <
		SceneObjects.size(); ObjectIterator++)
	{
		// Only check for collision between controlled objects/moveable obstacles
		// and any other objects (as static obstacles will not collide with other
		// objects):
		GameObject* CurrentObject = SceneObjects[ObjectIterator];

		if (CurrentObject && CurrentObject->ObjectModelFileReferenceValid() && 
			(CurrentObject->GetObjectModelFileName() == PLAYER_FILE_PATH ||
			CurrentObject->GetObjectModelFileName() == ENEMY_FILE_PATH))
		{
			for (UINT Iterator = 0u; Iterator < SceneObjects.size();
				Iterator++)
			{
				if (SceneObjects[Iterator] != CurrentObject)
				{
					if (CurrentObject->CheckCollision(SceneObjects[Iterator]))
					{
						// Pick-up this object:
						if (RepositionGameObject(CurrentObject, SceneObjects[Iterator]))
						{
							// The object at Iterator position in SceneObjects is a CollectableObject, 
							// so clean it up (erase the pointer at Iterator position):
							SceneObjects.erase(std::remove(SceneObjects.begin(), SceneObjects.end(),
								SceneObjects[Iterator]), SceneObjects.end());
							/**
								Above collection clean-up method was found at:
								https://stackoverflow.com/questions/3385229/c-erase-vector-element-by-value-rather-than-by-position
							*/

							// Add to the amount of capsules the Player has collected:
							PlayerHoverTankReference->CapsuleCollected();
						}
					}
				}
			}
		}		
	}
}

// Reposition the OffendingObject to a position that is not colliding
// with VictimObject (or remove the VictimObject if it is a collectable):
bool GameScene::RepositionGameObject(GameObject*& OffendingObject, 
	GameObject*& VictimObject)
{
	// The return value:
	bool VictimObjectIsCollectableObject = false;

	// Push the OffendingObject away from the VictimObject:
	if (dynamic_cast<StaticObstacle*>(VictimObject))
	{
		PushBackControlledObject(OffendingObject, VictimObject);
	}	

	// Push the VictimObject away from the OffendingObject:
	if (dynamic_cast<MoveableObstacle*>(VictimObject))
	{
		PushAwayMoveableObstacle(OffendingObject, VictimObject);
	}

	// Push the OffendingObject away from the VictimObject
	// (EnemyHoverTank away from the PlayerHoverTank):
	if (dynamic_cast<PlayerHoverTank*>(VictimObject))
	{
		PushBackControlledObject(OffendingObject, VictimObject);
		// Damage the Player:
		PlayerHoverTankReference->ModifyHealth(dynamic_cast<EnemyHoverTank*>
			(OffendingObject)->ENEMY_DAMAGE_TO_PLAYER);
	}

	// Remove VictimObject from the scene (if the Player 
	// has collided with it):
	if (dynamic_cast<CollectableObject*>(VictimObject) &&
		dynamic_cast<PlayerHoverTank*>(OffendingObject))
	{
		VictimObjectIsCollectableObject = true;
	}

	return VictimObjectIsCollectableObject;
}

// Push back the controlled-object (the OffendingObject has collided
// with a static-object):
void GameScene::PushBackControlledObject(GameObject*& OffendingObject,
	GameObject*& VictimObject)
{
	ControlledObject* OffendingControlledObject = dynamic_cast
		<ControlledObject*>(OffendingObject);

	// Repel the offending object:
	StaticObstacle* StaticObstacleVictim = dynamic_cast<StaticObstacle*>(VictimObject);
	if (StaticObstacleVictim)
	{
		OffendingControlledObject->RepelControlledObject(StaticObstacleVictim->
				REPULSION_FORCE_MAGNITUDE);
		return;
	}

	if (VictimObject == PlayerHoverTankReference)
	{
		OffendingControlledObject->RepelControlledObject(PlayerHoverTankReference
			->REPULSION_FORCE_MAGNITUDE);
	}
	
}

// Push back the VictimObject (the OffendingObject has collided with a
// MoveableObstacle:
void GameScene::PushAwayMoveableObstacle(GameObject*& OffendingObject,
	GameObject*& VictimObject)
{
	dynamic_cast<MoveableObstacle*>(VictimObject)->
		OnImpact(dynamic_cast<ControlledObject*>(OffendingObject)
			->GetObjectMovementDirection());
}

void GameScene::SetupCustomWorldViewProjectionMatrix(XMMATRIX& Projection,
	XMMATRIX& World, XMMATRIX& View, const XMVECTOR& NewTranslation,
	const XMMATRIX & NewRotation, WindowClass *& WindowClassHandleReference, 
	DirectXSystem *& DirectXSystemHandleReference)
{
	FLOAT SineFov;
	FLOAT CoSineFov;
	FLOAT Height;
	FLOAT Width;
	FLOAT HalfDefaultFOV = XMConvertToRadians(DEFAULT_FIELD_OF_VIEW) * 0.50f;
	FLOAT FOVAspectRatio = WindowClassHandleReference->GetFOVAspectRatio();
	const FLOAT NEAR_Z = 1.0f;
	const FLOAT FAR_Z = 1000.0f;
	XMMATRIX PerspectiveProjectionMatrix;

	// Modifiy the rotation first, before translating the object:
	World *= XMMatrixTranslationFromVector(NewTranslation);
	World *= NewRotation;

	// Get the cosine and sine of the FOV first...
	XMScalarSinCos(&SineFov, &CoSineFov, HalfDefaultFOV);
	Height = CoSineFov / SineFov;
	Width = Height / FOVAspectRatio;

	PerspectiveProjectionMatrix.r[0] = XMVectorSet(Width, 0.0f, 0.0f, 0.0f);
	PerspectiveProjectionMatrix.r[1] = XMVectorSet(0.0f, Height, 0.0f, 0.0f);
	PerspectiveProjectionMatrix.r[2] = XMVectorSet(0.0f, 0.0f, FAR_Z / (FAR_Z - NEAR_Z), 1.0f);
	PerspectiveProjectionMatrix.r[3] = XMVectorSet(0.0f, 0.0f, -(PerspectiveProjectionMatrix.r[2].vector4_f32[2] * NEAR_Z), 0.0f);

	Projection = PerspectiveProjectionMatrix;

	View = PlayerHoverTankReference->GetPlayerCameraReference()->GetViewMatrix();

	DirectXSystemHandleReference->UpdateConstantBuffer(Projection, World, 
		View, PlayerHoverTankReference->GetDirectionalLightShinesFrom(),
		PlayerHoverTankReference->GetDirectionalLightColour(), 
		PlayerHoverTankReference->GetAmbientLightColour());
}

// Set-up a reference to the Player's hover-tank:
void GameScene::GetPlayerHoverTankReference()
{
	for each (GameObject* CurrentObject in SceneObjects)
	{
		if (CurrentObject->GetObjectModelFileName() ==
			PLAYER_FILE_PATH)
		{
			PlayerHoverTankReference =
				dynamic_cast<PlayerHoverTank*>(CurrentObject);
			return;
		}
	}
}

// Set-up references to Enemy hover-tanks:
void GameScene::GetEnemyHoverTankReferences()
{
	for each (GameObject* CurrentObject in SceneObjects)
	{
		if (CurrentObject->GetObjectModelFileName() ==
			ENEMY_FILE_PATH)
		{
			EnemyHoverTanksReference.push_back(
				dynamic_cast<EnemyHoverTank*>(CurrentObject));
		}
	}
}

void GameScene::UpdateEnemyHoverTanks()
{
	for each (EnemyHoverTank* ThisEnemy in EnemyHoverTanksReference)
	{
		if (ThisEnemy)
		{
			ThisEnemy->ManageAIState(PlayerHoverTankReference);
		}
	}
}
