#include <windows.h>
#include <Windows.h>
#include <d3d11.h>
#include <d3dx11.h>
#include <dxerr.h>

/**
	RESOLUTIONS NOTED HERE:

	1. To resolve macro redefinition warnings, add $(WindowsSDK_IncludePath)
	as the first include directory in VC++ Include Directories, within the
	project settings.

	2. For 'Warning	C4838 conversion from 'unsigned int' to 'INT' requires a narrowing conversion'.
	Philip says to ignore these warnings if they are pointing to a DirectX related file (in respects
	to an outdated library), but if these warnings point to your code, cast any values setting INT
	values to unsigned (using 'u')).

	3. Resolved Live Object/Producer warnings, by following the tutorial here: 
	http://masterkenth.com/directx-leak-debugging/. 

	4. Resolved models not being rendered as they appear in 3DSMax,
	by changing the primitive topology from TRIANGLESTRIP to
	TRIANGLELIST.
*/

/**
	TASK LIST:

	1. Make sure this project runs on multiple workstations, given different settings.
	2. Note process for resolving issue with model not facing the camera.
	3. Note my use of pointer references in the report (why, how etc.).
	4. Attempt to resolve issues with translation depending on orientation
	by determining the forward vector given an object's oreintation, then using
	that to work out the other directions
*/

#define _XM_NO_INTRINSICS_
#define XM_NO_ALIGNMENT
#include <xnamath.h>

/** To use instead of an array of characters. */
#include <string>

/**
	A legacy file for references, that still holds on to certain values (e.g. for 
	virtual key-codes). 
*/
#include "GlobalReferences.h"

/** For the Player's perspective. */
#include "Camera.h"

/** This class encapsulates the win32 behavior. */
#include "WindowClass.h"

/** To handle setting-up and rendering via DirectX 11. */
#include "DirectXSystem.h"

/** For scene mangement. */
#include "SceneManager.h"

/** For the Player. */
#include "PlayerHoverTank.h"

/** For enemies. */
#include "EnemyHoverTank.h"

/** For static-obstacles. */
#include "StaticObstacle.h"

/** 
	For assertions (add '#define NDEBUG' above this include 
	line, to disable the 'assert' macro). 
	Reference source:
	http://www.cplusplus.com/reference/cassert/assert/
*/
#include <assert.h>

/** 
	DirectX related pointers are declared here. 
*/

/** For window handling. */
WindowClass* WindowClassHandle;

/** For handling DirectX. */
DirectXSystem* DirectXSystemHandle;

/** 
	To manage the scenes of objects that
	are shown to the Player.
*/
SceneManager* SceneManagerHandle;

/** For the Player's in-game representation. */
PlayerHoverTank* PlayerHoverTankReference;

/** For the in-game representation of enemies. */
std::vector<EnemyHoverTank*> EnemyHoverTanksReference;

DirectXSystem::NonControlledSceneObjects* NonControlledScene0Objects;

/** To initialise the SceneManager. */
std::vector<SceneManager::SceneComponents*> GameSceneValues;

/** Incremented by 1 for each scene. */
int SceneIDCounter = 0;

/**
	End of DirectX related pointer delcaration.
*/

//////////////////////////////////////////////////////////////////////////////////////
// Entry point to the program. Initializes everything and goes into a message processing 
// loop. Idle time is used to render the scene.
//////////////////////////////////////////////////////////////////////////////////////
int WINAPI WinMain(HINSTANCE InstanceHandle, HINSTANCE PreviousInstanceHandle, LPSTR lpCmdLine, int nCmdShow)
{
	// For certain function calls:
	HRESULT ResultHandle = S_OK;

	UNREFERENCED_PARAMETER(PreviousInstanceHandle);
	UNREFERENCED_PARAMETER(lpCmdLine);

	// Initialise bespoke class pointers:
	DefaultProgramConstructor();
	
	// Stop here if any of the pointers 
	// are invalid:
	assert(WindowClassHandle);
	assert(DirectXSystemHandle);

	if (FAILED(WindowClassHandle->InitialiseWindow(InstanceHandle, nCmdShow, WndProc)))
	{
		DXTRACE_MSG("Failed to create Window");
		return 0;
	}

	if (FAILED(DirectXSystemHandle->InitialiseD3D(WindowClassHandle->
		GetWindowHandle())))
	{
		DXTRACE_MSG("Failed to create Device");
		return 0;
	}

	if (FAILED(DirectXSystemHandle->InitialiseGraphics(
		PlayerHoverTankReference, NonControlledScene0Objects,
		EnemyHoverTanksReference)))
	{
		DXTRACE_MSG("Failed to initialise graphics");
		return 0;
	}

	// As these are initialised via DirectXSystem::InitialiseGraphics():
	assert(PlayerHoverTankReference->GetPlayerCameraReference());
	assert(PlayerHoverTankReference);
	for each (EnemyHoverTank* CurrentTank in EnemyHoverTanksReference)
	{
		assert(CurrentTank);
	}

	// For one scene at the moment:
	std::vector<GameObject*> DefaultSceneObjects = { PlayerHoverTankReference };
	// Add of the Enemy hover-tanks into this collection as well:
	for each (EnemyHoverTank* CurrentTank in EnemyHoverTanksReference)
	{
		DefaultSceneObjects.push_back(CurrentTank);
	}
	
	// Static obstacles:
	for (UINT Iterator = 0u; Iterator < NonControlledScene0Objects->
		StaticObstaclesReference.size(); Iterator++)
	{
		if (NonControlledScene0Objects->StaticObstaclesReference[Iterator])
		{
			DefaultSceneObjects.push_back(NonControlledScene0Objects->
				StaticObstaclesReference[Iterator]);
		}
	}

	// Moveable obstacles:
	for (UINT Iterator = 0u; Iterator < NonControlledScene0Objects->
		MoveableObstaclesReference.size(); Iterator++)
	{
		if (NonControlledScene0Objects->MoveableObstaclesReference[Iterator])
		{
			DefaultSceneObjects.push_back(NonControlledScene0Objects->
				MoveableObstaclesReference[Iterator]);
		}
	}

	// Collectable objects:
	for (UINT Iterator = 0u; Iterator < NonControlledScene0Objects->
		CollectableObjectsReference.size(); Iterator++)
	{
		if (NonControlledScene0Objects->CollectableObjectsReference[Iterator])
		{
			DefaultSceneObjects.push_back(NonControlledScene0Objects->
				CollectableObjectsReference[Iterator]);
		}
	}

	GameSceneValues.push_back(new SceneManager::
		SceneComponents(DefaultSceneObjects, SceneIDCounter, 
			true));

	SceneManagerHandle = new SceneManager(
		DirectXSystemHandle->GetImmediateContextReference(),
		GameSceneValues);
	assert(SceneManagerHandle);

	// Main message loop
	MSG PrimaryMessage = { 0 };

	while (PrimaryMessage.message != WM_QUIT)
	{
		if (PeekMessage(&PrimaryMessage, NULL, 0, 0, PM_REMOVE))
		{
			TranslateMessage(&PrimaryMessage);
			DispatchMessage(&PrimaryMessage);
		}
		else
		{
			if (FAILED(SceneManagerHandle->UpdateGameScenes(DirectXSystemHandle->
				GetBackBufferRenderTargetViewReference(), 
				DirectXSystemHandle->GetSwapChainReference(), DirectXSystemHandle->
				GetVertexBufferReference(),
				DirectXSystemHandle->GetZBufferReference(),
				DirectXSystemHandle->GetConstantBuffer0Reference(), 
				WindowClassHandle, DirectXSystemHandle)))
			{
				DXTRACE_MSG("Failed to update scenes");
				return 0;
			}

			// Player wins:
			if (SceneManagerHandle->GetDefaultGameScene()->GetPlayerHasWon())
			{
				// For the splash screen to use:
				const XMVECTOR TARGET_POSITION = PlayerHoverTankReference->GetVectorPosition() + XMVectorSet(0.0f, 0.0f, 40.0f, 0.0f);
				XMFLOAT3 TargetPositionFloat3 = XMFLOAT3();
				XMStoreFloat3(&TargetPositionFloat3, TARGET_POSITION);

				// Show the Loss indicator to the Player:
				GameObject* PlayerVictorySplashScreen = new GameObject(DirectXSystemHandle->
					GetD3DDeviceReference(), DirectXSystemHandle->GetImmediateContextReference(),
					ResultHandle, TargetPositionFloat3);

				// Leave the function now:
				if (PlayerVictorySplashScreen)
				{
					ResultHandle = PlayerVictorySplashScreen->LoadObjectModel(
						GENERIC_SPLASH_SCREEN_FILE_PATH);

					PlayerVictorySplashScreen->Draw(&SceneManagerHandle->GetDefaultGameScene()->GetViewMatrix(),
						&SceneManagerHandle->GetDefaultGameScene()->GetProjectionMatrix());
					Sleep(VICTORY_LOSS_FREEZE_TIME);
					PrimaryMessage.message = WM_QUIT;

					// No longer required:
					delete PlayerVictorySplashScreen;
					PlayerVictorySplashScreen = nullptr;
				}
			}

			// Player loses:
			if (!SceneManagerHandle->GetDefaultGameScene()->GetPlayerIsAlive())
			{
				// For the splash screen to use:
				const XMVECTOR TARGET_POSITION = PlayerHoverTankReference->GetVectorPosition() + XMVectorSet(0.0f, 0.0f, 40.0f, 0.0f);
				XMFLOAT3 TargetPositionFloat3 = XMFLOAT3();
				XMStoreFloat3(&TargetPositionFloat3, TARGET_POSITION);

				// Show the Loss indicator to the Player:
				GameObject* PlayerLossSplashScreen = new GameObject(DirectXSystemHandle->
					GetD3DDeviceReference(), DirectXSystemHandle->GetImmediateContextReference(),
					ResultHandle, TargetPositionFloat3);

				// Leave the function now:
				if (PlayerLossSplashScreen)
				{
					ResultHandle = PlayerLossSplashScreen->LoadObjectModel(
						GENERIC_SPLASH_SCREEN_FILE_PATH);

					PlayerLossSplashScreen->Draw(&SceneManagerHandle->GetDefaultGameScene()->GetViewMatrix(),
						&SceneManagerHandle->GetDefaultGameScene()->GetProjectionMatrix());
					Sleep(VICTORY_LOSS_FREEZE_TIME);
					PrimaryMessage.message = WM_QUIT;

					// No longer required:
					delete PlayerLossSplashScreen;
					PlayerLossSplashScreen = nullptr;
				}
			}
		}		
	}
	
	// For closing Direct3D correctly:
	ShutdownD3D();

	return (int) PrimaryMessage.wParam;
}

// Initialise this application:
void DefaultProgramConstructor()
{
	WindowClassHandle = new WindowClass();
	DirectXSystemHandle = new DirectXSystem();
}

//////////////////////////////////////////////////////////////////////////////////////
// Called every time the application receives a message
//////////////////////////////////////////////////////////////////////////////////////
LRESULT CALLBACK WndProc(HWND WindowHandle, UINT Message, WPARAM WParam, LPARAM LParam)
{
	// For checking to see if the message is not equal to the values accounted for
	// in the switch statement of WindowsProcedureLogic():
	HRESULT ResultHandle = WindowClassHandle->WindowsProcedureLogic
	(WindowHandle, Message, WParam, LParam, DirectXSystemHandle, 
		PlayerHoverTankReference);

	if (ResultHandle == E_FAIL)
	{
		return DefWindowProc(WindowHandle, Message, WParam, LParam);
	}

	return 0;
}

//////////////////////////////////////////////////////////////////////////////////////
// Clean up D3D objects:
//////////////////////////////////////////////////////////////////////////////////////
void ShutdownD3D()
{
	if (PlayerHoverTankReference) delete PlayerHoverTankReference; PlayerHoverTankReference = nullptr;
	for each (EnemyHoverTank* CurrentEnemy in EnemyHoverTanksReference)
	{
		if (CurrentEnemy)
		{
			delete CurrentEnemy;
			CurrentEnemy = nullptr;
		}
	}

	for each (StaticObstacle* CurrentObstacle in NonControlledScene0Objects->StaticObstaclesReference)
	{
		if (CurrentObstacle)
		{
			delete CurrentObstacle;
			CurrentObstacle = nullptr;
		}
	}
	for each(MoveableObstacle* CurrentObstacle in NonControlledScene0Objects->MoveableObstaclesReference)
	{
		if (CurrentObstacle)
		{
			delete CurrentObstacle;
			CurrentObstacle = nullptr;
		}
	}
	for each (CollectableObject* CurrentCollectable in NonControlledScene0Objects->CollectableObjectsReference)
	{
		if (CurrentCollectable)
		{
			delete CurrentCollectable;
			CurrentCollectable = nullptr;
		}
	}
	if (NonControlledScene0Objects) delete NonControlledScene0Objects; NonControlledScene0Objects = nullptr;
	if (SceneManagerHandle) delete SceneManagerHandle; SceneManagerHandle = nullptr;
	if (DirectXSystemHandle) delete DirectXSystemHandle; DirectXSystemHandle = nullptr;
	if (WindowClassHandle) delete WindowClassHandle; WindowClassHandle = nullptr;
}