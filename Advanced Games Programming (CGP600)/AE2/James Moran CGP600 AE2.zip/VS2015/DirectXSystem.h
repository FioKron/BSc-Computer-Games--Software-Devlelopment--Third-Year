#pragma once

#include <Windows.h>
#include <windows.h>
#include "Camera.h"
#include "PlayerHoverTank.h"
#include "EnemyHoverTank.h"
#include "StaticObstacle.h"
#include "MoveableObstacle.h"
#include "CollectableObject.h"

class DirectXSystem
{

public:

	// Structures:

	/** To manage the camera */
	struct CONSTANT_BUFFER0
	{
		XMMATRIX WorldViewProjectionMatrix; // '64 bytes'
		float Scale; // 4 bytes
		XMFLOAT3 ScalePacking; // 3x4 bytes = 12 bytes
		XMFLOAT4 NewPosition; // 4x4 bytes = 16 bytes
		bool InputProvided; // 1 byte
		bool PackingInputBytes[3]; // 3 bytes (1x3)
		XMFLOAT3 AdditionalPackingInputBytes; // 3x4 bytes = 12 bytes
		XMVECTOR DirectionalLightVector; // '16 bytes'
		XMVECTOR DirectionalLightColour; // '16 bytes'
		XMVECTOR AmbientLightColour; // '16 bytes'

		/** Standard 'constructor' */
		void Initialise()
		{
			WorldViewProjectionMatrix = XMMATRIX();
			Scale = 0.0f;
			ScalePacking = XMFLOAT3(0.0f, 0.0f, 0.0f);
			NewPosition = XMFLOAT4(0.0f, 0.0f, 0.0f, 0.0f);
			InputProvided = false;
			for each (bool CurrentValue in PackingInputBytes)
			{
				CurrentValue = false;
			}
			AdditionalPackingInputBytes = XMFLOAT3(0.0f, 0.0f, 0.0f);
			DirectionalLightVector = XMVectorSet(0.0f, 0.0f, 0.0f, 0.0f);
			DirectionalLightColour = XMVectorSet(0.0f, 0.0f, 0.0f, 0.0f);
			AmbientLightColour = XMVectorSet(0.0f, 0.0f, 0.0f, 0.0f);			
		}
	}; /** Total size: 160 bytes. */

	/** 'Define vertex structure'. */
	struct POS_COL_TEX_NORM_VERTEX
	{
		XMFLOAT3 Position;
		XMFLOAT3 Color;
		XMFLOAT2 TextureUVCoordinates;
		XMFLOAT3 Normal;
	};

	/** 
		From Main.cpp (for obstacles
		in the scene). 
	*/
	struct NonControlledSceneObjects
	{
		/**
			To refer to the assets in this scene.
		*/
		std::vector<StaticObstacle*>
			StaticObstaclesReference;
		std::vector<MoveableObstacle*>
			MoveableObstaclesReference;
		std::vector<CollectableObject*>
			CollectableObjectsReference;

		/**
			For the quantity of each type of 
			obstacle.
		*/
		int StaticObstacleCount;
		int MoveableObstacleCount;
		int CollectableObjectCount;

		/** Standard constructor. */
		NonControlledSceneObjects::NonControlledSceneObjects(
			int NewStaticObstacleCount, 
			int NewMoveableObstacleCount,
			int NewCollectableObjectCount)
		{
			StaticObstacleCount = NewStaticObstacleCount;
			MoveableObstacleCount = NewMoveableObstacleCount;
			CollectableObjectCount = NewCollectableObjectCount;
		}
	};

	// Functions:

	/** Standard constructor. */
	DirectXSystem();

	/** Standard destructor. */
	~DirectXSystem();

	/** Initialise the Direct3D system. */
	HRESULT InitialiseD3D(HWND& WindowHandle);

	/**
		Initialise the graphics system,
		used by Direct3D, in this application.
	*/
	HRESULT InitialiseGraphics(PlayerHoverTank*& 
		PlayerHoverTankReference,
		NonControlledSceneObjects*&
		Scene0ObjectsReference,
		std::vector<EnemyHoverTank*>& 
		EnemyHoverTanksReference);

	/** If ever the window is resized. */
	HRESULT HandleWindowResizing(HWND& WindowHandle);

	/** Update the constant buffer's values, for the current transformation. */
	void UpdateConstantBuffer(XMMATRIX& Projection, XMMATRIX& World,
		XMMATRIX& View, XMVECTOR& DirectionalLightVector, 
		XMVECTOR& DirectionalLightColour, XMVECTOR& AmbientLightColour);

	// Get Functions:

	ID3D11DeviceContext*& GetImmediateContextReference();
	IDXGISwapChain*& GetSwapChainReference();
	ID3D11RenderTargetView*& GetBackBufferRenderTargetViewReference();

	/** For getting references to the different types of buffers. */
	ID3D11Buffer*& GetConstantBuffer0Reference();
	ID3D11Buffer*& GetVertexBufferReference();
	ID3D11Buffer*& GetIndexBufferReference();
	ID3D11DepthStencilView*& GetZBufferReference();

	/** For shaders. */
	ID3D11ShaderResourceView*& GetPlayerHoverTankTextureReference();
	ID3D11ShaderResourceView*& GetStaticRockTextureReference();
	ID3D11ShaderResourceView*& GetWoodenBarrelTextureReference();
	ID3D11ShaderResourceView*& GetEnergyCapsuleTextureReference();
	ID3D11ShaderResourceView*& GetEnemyHoverTankTextureReference();
	ID3D11ShaderResourceView*& GetPlayerLossSplashScreenTexture();
	ID3D11ShaderResourceView*& GetPlayerVictorySplashScreenTexture();
	ID3D11SamplerState*& GetDefaultTextureSamplerReference();

	/** To refer to the D3DDevice. */
	ID3D11Device*& GetD3DDeviceReference();

	// Constant values:
	
	/** 
		The initial position for each object type, is where the first
		object of that type will be placed in the level.
	*/
	const int SCENE0_STATIC_OBSTACLE_COUNT = 20;
	const XMFLOAT3 STATIC_OBSTACLE_INITIAL_POSITION = XMFLOAT3(-500.0f, 0.0f, 0.0f);
	const int SCENE0_MOVEABLE_OBSTACLE_COUNT = 20;
	const XMFLOAT3 MOVEABLE_OBSTACLE_INITIAL_POSITION = XMFLOAT3(-500.0f, 0.0f, 250.0f);
	const int SCENE0_COLLECTABLE_OBJECT_COUNT = 20;
	const XMFLOAT3 COLLECTABLE_OBJECT_INITIAL_POSITION = XMFLOAT3(-500.0f, 0.0f, 500.0f);
	const XMFLOAT3 DEFAULT_POSITION_INCREMENTOR = XMFLOAT3(50.0f, 0.0f, 0.0f);

	/** 
		For game-scene assets.
	*/
	const std::string DEFAULT_PLAYER_MODEL_FILE_PATH = "Assets/PlayerShip.obj";
	const std::string DEFAULT_ENEMY_MODEL_FILE_PATH = "Assets/EnemyHoverTank.obj"; 
	const std::string DEFAULT_STATIC_OBSTACLE_FILE_PATH = "Assets/StaticRock.obj";
	const std::string DEFAULT_MOVEABLE_OBSTACLE_FILE_PATH = "Assets/WoodenBarrel.obj";
	const std::string DEFAULT_COLLECTABLE_OBJECT_FILE_PATH = "Assets/EnergyCapsule.obj";
	const std::string DEFAULT_PLAYER_MODEL_TEXTURE_FILE_PATH = "Assets/PlayerHoverTankTexture.tiff";
	const std::string DEFAULT_STATIC_ROCK_TEXTURE_FILE_PATH = "Assets/StaticRockTexture.jpg";
	const std::string DEFAULT_WOODEN_BARREL_TEXTURE_FILE_PATH = "Assets/WoodenBarrelTexture.jpg";
	const std::string DEFAULT_ENERGY_CAPSULE_TEXTURE_FILE_PATH = "Assets/EnergyCapsuleTexture.jpg";
	const std::string DEFAULT_ENEMY_MODEL_TEXTURE_FILE_PATH = "Assets/EnemyHoverTankTextureImage.tiff";
	const std::string PLAYER_VICTORY_SPLASH_SCREEN_TEXTURE_FILE_PATH = 
		"Assets/PlayerVictoryTexture.png";
	const std::string PLAYER_LOSS_SPLASH_SCREEN_TEXTURE_FILE_PATH = "Assets/PlayerLossTexture.png";

	/** For 'random' placement. */
	const int MINIMUM_XZ_POSITION = -100;
	const int MAXIMUM_XZ_POSITION = 100;

	/**
		(These two values were constant, 
		but changed for parsing into con-
		structors):
		Default position values for the
		Player's hover-tank.
	*/
	XMFLOAT3 DEFAULT_PLAYER_MODEL_LOCATION = XMFLOAT3(0.0f, 0.0f, 1000.0f);

	/** For the Enemy hover-tank. */
	XMFLOAT3 DEFAULT_FIRST_ENEMY_HOVER_TANK_LOCATION = XMFLOAT3(0.0f, 0.0f, -1000.0f);
	const int ENEMY_HOVER_TANK_QUANTITY = 1;

	/**
		For the number of vertices present in the shape to draw.
		For a certain reason, this has to be (at least) 1 greater than the
		number of vertices to be drawn, to draw them...
		This is for a cube that uses vertices.
	*/
	const UINT VERTEX_COUNT = 17;

	/**
		Default value to clear the viewport to,
		before drawing to it.
	*/
	const float DEFAULT_CLEAR_COLOUR[4] = { 1.0f, 1.0f, 1.0f, 1.0f };

private:

	// Properties:

	/** 
		For the types of drivers and respective DirectX 11 
		features to use. 
	*/
	D3D_DRIVER_TYPE DriverTypeReference = D3D_DRIVER_TYPE_NULL;
	D3D_FEATURE_LEVEL FeatureLevelReference = D3D_FEATURE_LEVEL_11_0;

	/** 
		A reference to the device for DirectX, as well as the 
		hardware context along with a reference to the swap-chain
		(important for swapping between the front and back buffers,
		as one draws to the back buffer, then swaps this buffer with
		the front buffer to become the new front buffer; showing what
		has been drawn).
	*/
	ID3D11Device* D3DDeviceReference = nullptr;
	ID3D11DeviceContext* ImmediateContextReference = nullptr;
	IDXGISwapChain* SwapChainReference = nullptr;

	/**
		To refer to the shaders and their input-layout.
	*/
	ID3D11VertexShader* VertexShader = nullptr;
	ID3D11PixelShader* PixelShader = nullptr;
	ID3D11InputLayout* InputLayout = nullptr;

	ID3D11ShaderResourceView* PlayerHoverTankTexture = nullptr;
	ID3D11ShaderResourceView* StaticRockTexture = nullptr;
	ID3D11ShaderResourceView* WoodenBarrelTexture = nullptr;
	ID3D11ShaderResourceView* EnergyCapsuleTexture = nullptr;
	ID3D11ShaderResourceView* EnemyHoverTankTexture = nullptr;
	ID3D11ShaderResourceView* PlayerVictorySplashScreenTexture = nullptr;
	ID3D11ShaderResourceView* PlayerLossSplashScreenTexture = nullptr;
	ID3D11SamplerState* DefaultTextureSampler = nullptr;

	/** To show objects in front of and behind each other */
	ID3D11DepthStencilView* ZBuffer = nullptr;

	/** The one and only constant buffer */
	ID3D11Buffer* ConstantBuffer0 = nullptr;
	CONSTANT_BUFFER0 ConstantBuffer0Values;

	/** For indices */
	ID3D11Buffer* IndexBuffer = nullptr;

	/** To hold onto the vertices to draw */
	ID3D11Buffer* VertexBuffer = nullptr;

	/** For whatever has been drawn, to then be swapped with the front buffer */
	ID3D11RenderTargetView* BackBufferRenderTargetViewReference = nullptr;

	/** For the placement of non-controlled objects. */
	XMFLOAT3 CurrentStaticObstaclePosition;
	XMFLOAT3 CurrentMoveableObstaclePosition;
	XMFLOAT3 CurrentCollectableObjectPosition;

	// Constant Values:

	/** The first and only constant buffer that is used */
	const UINT FIRST_CONSTANT_BUFFER_BYTE_WIDTH = 160u;

	// Functions:

	// Initialisers:

	/** 
		For the non-controlled
		scene-objects of each type.
	*/
	HRESULT InitialiseStaticObstacles(
		NonControlledSceneObjects*&
		Scene0ObjectsReference, HRESULT&
		ResultHandleReference);
	HRESULT InitialiseMoveableObstacles(
		NonControlledSceneObjects*&
		Scene0ObjectsReference, HRESULT&
		ResultHandleReference);
	HRESULT InitialiseCollectableObjects(
		NonControlledSceneObjects*&
		Scene0ObjectsReference, HRESULT&
		ResultHandleReference);

	/**
		For any texture of a GameObject.
	*/
	void InitialiseTexture(std::string TextureFilePath,
		ID3D11ShaderResourceView*& TextureReference);

	/** Set-up the shaders for use in drawing graphics */
	HRESULT SetUpShaders(HRESULT ResultHandle);

	/** For varience in object placement */
	XMFLOAT3 GetNewObjectPosition();

	// Debugging:

	/** For checking on D3D11 Warnings */
	void ReportLiveObjects();
};

