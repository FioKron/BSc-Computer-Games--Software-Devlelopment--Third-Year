#include "MoveableObstacle.h"



// Initialise (using an initialiser list)
MoveableObstacle::MoveableObstacle(ID3D11Device*& NewD3DDeviceReference, ID3D11DeviceContext*&
	NewD3DDeviceContextReference, HRESULT& ResultHandleReference,
	XMFLOAT3& InitialPosition)
	: GameObject(NewD3DDeviceReference, NewD3DDeviceContextReference, ResultHandleReference,
		InitialPosition)
{

}

// Clean-up:
MoveableObstacle::~MoveableObstacle()
{

}

// When this obstacle is hit:
void MoveableObstacle::OnImpact(XMVECTOR& ImpactDirection)
{
	// Move the obstacle:
	PositionVector += PUSH_FORCE_MAGNITUDE * ImpactDirection;
}
