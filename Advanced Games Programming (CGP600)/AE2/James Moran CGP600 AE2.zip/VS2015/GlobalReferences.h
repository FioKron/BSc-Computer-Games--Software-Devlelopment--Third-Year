#pragma once

#include <string>

// Global Properties:

// Constant values:

/** For the respective Virtual-Key codes */

// Numbers (not from the numpad):

const UINT VK_0 = 0x30u;
const UINT VK_1 = 0x31u;
const UINT VK_2 = 0x32u;
const UINT VK_3 = 0x33u;
const UINT VK_4 = 0x34u;
const UINT VK_5 = 0x35u;
const UINT VK_6 = 0x36u;
const UINT VK_7 = 0x37u;
const UINT VK_8 = 0x38u;
const UINT VK_9 = 0x39u;

// Leters:

const UINT VK_AKEY = 0x41u;
const UINT VK_BKEY = 0x42u;
const UINT VK_CKEY = 0x43u;
const UINT VK_DKEY = 0x44u;
const UINT VK_EKEY = 0x45u;
const UINT VK_FKEY = 0x46u;
const UINT VK_GKEY = 0x47u;
const UINT VK_HKEY = 0x48u;
const UINT VK_IKEY = 0x49u;
const UINT VK_JKEY = 0x4Au;
const UINT VK_KKEY = 0x4Bu;
const UINT VK_LKEY = 0x4Cu;
const UINT VK_MKEY = 0x4Du;
const UINT VK_NKEY = 0x4Eu;
const UINT VK_OKEY = 0x4Fu;
const UINT VK_PKEY = 0x50u;
const UINT VK_QKEY = 0x51u;
const UINT VK_RKEY = 0x52u;
const UINT VK_SKEY = 0x53u;
const UINT VK_TKEY = 0x54u;
const UINT VK_UKEY = 0x55u;
const UINT VK_VKEY = 0x56u;
const UINT VK_WKEY = 0x57u;
const UINT VK_XKEY = 0x58u;
const UINT VK_YKEY = 0x59u;
const UINT VK_ZKEY = 0x5Au;

// To load the splash screen's default asset:
const std::string GENERIC_SPLASH_SCREEN_FILE_PATH = "Assets/GenericSplashScreen.obj";

/** How long to sleep for before terminating the application. */
const DWORD VICTORY_LOSS_FREEZE_TIME = 3000ul;

//////////////////////////////////////////////////////////////////////////////////////
//	Forward declarations (functions/methods):
//////////////////////////////////////////////////////////////////////////////////////
LRESULT CALLBACK WndProc(HWND WindowHandle, UINT Message, WPARAM
	WParam, LPARAM LParam);

/**
	This function initialises the pointers declared in 
	Main.cpp.
*/
void DefaultProgramConstructor();

void ShutdownD3D();