#pragma once

#include "GameObject.h"

/**
	This is the class that Energy Capsules
	use in game, for their representation
	(as handled by the GameObject class).
*/

class CollectableObject : public GameObject
{

public:

	// Functions:

	/** Standard constructor. */
	CollectableObject(ID3D11Device*& NewD3DDeviceReference, ID3D11DeviceContext*&
		NewD3DDeviceContextReference, HRESULT& ResultHandleReference,
		XMFLOAT3& InitialPosition);

	/** Standard destructor. */
	~CollectableObject();
};

