#include "EnemyHoverTank.h"

// Initialise (using an initialiser list):
EnemyHoverTank::EnemyHoverTank(ID3D11Device*& NewD3DDeviceReference, ID3D11DeviceContext*&
	NewD3DDeviceContextReference, HRESULT& ResultHandleReference,
	XMFLOAT3& InitialPosition) : ControlledObject(NewD3DDeviceReference, NewD3DDeviceContextReference,
		ResultHandleReference, InitialPosition)
{
	CurrentState = Initial;
}

// Clean-up:
EnemyHoverTank::~EnemyHoverTank()
{

}

// Handle management of the current AI-State:
void EnemyHoverTank::ManageAIState(PlayerHoverTank*& 
	PlayerHoverTankReference)
{
	switch (CurrentState)
	{
	case Initial:
		FindTarget(PlayerHoverTankReference);
		break;
		
	case HasTarget:
		MoveToTarget();
		break;

		// Keep moving to the target, even after 
		// one has been found:
	case MovingToTarget:
		MoveToTarget();
		break;

	default:
		break;
	}
}

// Get a target...
void EnemyHoverTank::FindTarget(PlayerHoverTank*&
	PlayerHoverTankReference)
{
	CurrentTarget = PlayerHoverTankReference;
	CurrentState = HasTarget;
}

// ...to turn-to-face towards...
void EnemyHoverTank::RotateToFace()
{
	RotationVector.y = atan2(PositionVector.x -
		CurrentTarget->GetVectorPosition().x, PositionVector.z
		- CurrentTarget->GetVectorPosition().z) * (180.0f / XM_PI);	

	// Update the rotation matrix now:
	float PitchRotationRadians = XMConvertToRadians(RotationVector.x);
	float YawRotationRadians = XMConvertToRadians(RotationVector.y);
	float RollRotationRadians = XMConvertToRadians(RotationVector.z);

	RotationMatrix = XMMatrixRotationRollPitchYaw(PitchRotationRadians,
		YawRotationRadians, RollRotationRadians);
}

// ...to then move towards:
void EnemyHoverTank::MoveToTarget()
{
	RotateToFace();
	MoveForward(ENEMY_TRANSLATION_MAGNITUDE);
}
