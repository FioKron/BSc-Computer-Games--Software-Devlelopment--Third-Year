#include "SceneManager.h"
#include "DirectXSystem.h"
#include "PlayerHoverTank.h"

// Initialise:
SceneManager::SceneManager(ID3D11DeviceContext* NewImmediateContextReference,
	std::vector<SceneComponents*>& NewGameSceneValues)
{
	// Make a new scene for each of the values in NewGameSceneValues:
	for each (SceneComponents* CurrentSceneValues in NewGameSceneValues)
	{
		GameScenes.push_back(new GameScene(CurrentSceneValues->SceneObjects,
			CurrentSceneValues->SceneID, CurrentSceneValues->SceneIsActive,
			NewImmediateContextReference));
	}
}

// Shut-Down:
SceneManager::~SceneManager()
{
	for each (GameScene* CurrentScene in GameScenes)
	{
		delete CurrentScene;
		CurrentScene = nullptr;
	}
}

HRESULT SceneManager::UpdateGameScenes(ID3D11RenderTargetView* BackBufferRenderTargetViewReference,
	IDXGISwapChain* SwapChainReference, ID3D11Buffer*& VertexBufferReference,
	ID3D11DepthStencilView*& ZBufferReference, ID3D11Buffer*& ConstantBuffer0Reference,
	WindowClass*& WindowClassHandleReference, DirectXSystem*& DirectXSystemHandleReference)
{
	HRESULT ResultHandle = S_OK;

	for each (GameScene* CurrentGameScene in GameScenes)
	{
		// Only update active scenes:
		if (CurrentGameScene->GetIsSceneActive())
		{
			ResultHandle =
				CurrentGameScene->UpdateGameScene(
					BackBufferRenderTargetViewReference,
					SwapChainReference, VertexBufferReference, 
					ZBufferReference, ConstantBuffer0Reference,
					WindowClassHandleReference, DirectXSystemHandleReference);

			if (FAILED(ResultHandle))
			{
				return ResultHandle;
			}
		}
		
	}

	return ResultHandle;
}

// Get the default game-scene (where ID = 0):
GameScene*& SceneManager::GetDefaultGameScene()
{
	for (UINT CollectionIterator = 0u; CollectionIterator <
		GameScenes.size(); CollectionIterator++)
	{
		// 0 is the default game-scene's ID:
		if (GameScenes[CollectionIterator]->
			GetUniqueSceneID() == 0)
		{
			return GameScenes[CollectionIterator];
		}
	}

	// Default to returning the first scene
	// in the collection, if one was not found
	// in the above for loop:
	return GameScenes[0];
}

