#include "GameObject.h"

// Structures:

struct MODEL_CONSTANT_BUFFER
{
	XMMATRIX WorldViewProjectionMatrix; // '64 bytes ( 4 x 4 = 16 floats x 4 bytes)'
	XMVECTOR DirectionalLightVector; // '16 bytes'
	XMVECTOR DirectionalLightColour; // '16 bytes'
	XMVECTOR AmbientLightColour; // '16 bytes'
}; // 'TOTAL SIZE = 112 bytes'


// Initialise:
GameObject::GameObject(ID3D11Device*& NewD3DDeviceReference, ID3D11DeviceContext*& NewD3DDeviceContextReference,
	HRESULT& ResultHandleReference, XMFLOAT3& InitialPosition)
{
	D3DDeviceReference = NewD3DDeviceReference;
	ImmediateContextReference = NewD3DDeviceContextReference;
	PositionVector = XMVECTOR();
	RotationVector = XMVECTOR();

	PositionFloat3 = InitialPosition;
	PositionVector = XMLoadFloat3(&PositionFloat3);
	BoundingSphereRadius = 0.0f;

	GameObjectScale = 1.0f;
	ObjectScaleVector = XMVectorSet(GameObjectScale, GameObjectScale, GameObjectScale, 0.0f);

	UpDirectionVector = XMVECTOR();
	UpDirectionVector.x = 0.0f;
	UpDirectionVector.y = 1.0f;
	UpDirectionVector.z = 0.0f;

	InitialiseShaders(ResultHandleReference);
	InitialiseConstantBuffers(ResultHandleReference);
	RotationMatrix = XMMatrixRotationRollPitchYawFromVector(RotationVector);
	World = XMMATRIX();

	DirectionalLightShinesFrom = XMVectorSet(0.0f, 0.0f, -1.0f, 0.0f);
	DirectionalLightColour = XMVectorSet(1.0f, 1.0f, 1.0f, 0.0f);
	AmbientLightColour = XMVectorSet(0.10f, 1.10f, 1.10f, 1.0f);
}

// Clean-up: 
GameObject::~GameObject()
{
	if (ObjectModelReference)
	{
		delete ObjectModelReference;
		ObjectModelReference = nullptr;
	}
	if (GameObjectVertexShaderReference)
	{
		GameObjectVertexShaderReference->Release();
		GameObjectVertexShaderReference = nullptr;
	}
	if (GameObjectPixelShaderReference)
	{
		GameObjectPixelShaderReference->Release();
		GameObjectPixelShaderReference = nullptr;
	}

	if (GameObjectInputLayoutReference)
	{
		GameObjectInputLayoutReference->Release();
		GameObjectInputLayoutReference = nullptr;
	}
	if (GameObjectConstantBufferReference)
	{
		GameObjectConstantBufferReference->Release();
		GameObjectConstantBufferReference = nullptr;
	}
}

// Find the model's centre point:
void GameObject::CalculateModelCentrePoint()
{
	XMFLOAT3 MaximumXYZValues = ZERO_FLOAT3;
	XMFLOAT3 MinimumXYZValues = ZERO_FLOAT3;

	for (UINT VerticesIterator = 0u; VerticesIterator <
		ObjectModelReference->numverts; VerticesIterator++)
	{
		if (ObjectModelReference->vertices[VerticesIterator]
			.Pos.x > MaximumXYZValues.x)
		{
			MaximumXYZValues.x = ObjectModelReference->
				vertices[VerticesIterator].Pos.x;
		}

		if (ObjectModelReference->vertices[VerticesIterator]
			.Pos.x < MinimumXYZValues.x)
		{
			MinimumXYZValues.x = ObjectModelReference->
				vertices[VerticesIterator].Pos.x;
		}

		if (ObjectModelReference->vertices[VerticesIterator]
			.Pos.y > MaximumXYZValues.y)
		{
			MaximumXYZValues.y = ObjectModelReference->
				vertices[VerticesIterator].Pos.y;
		}

		if (ObjectModelReference->vertices[VerticesIterator]
			.Pos.y < MinimumXYZValues.y)
		{
			MinimumXYZValues.y = ObjectModelReference->
				vertices[VerticesIterator].Pos.y;
		}

		if (ObjectModelReference->vertices[VerticesIterator]
			.Pos.z > MaximumXYZValues.z)
		{
			MaximumXYZValues.z = ObjectModelReference->
				vertices[VerticesIterator].Pos.z;
		}

		if (ObjectModelReference->vertices[VerticesIterator]
			.Pos.z < MinimumXYZValues.z)
		{
			MinimumXYZValues.z = ObjectModelReference->
				vertices[VerticesIterator].Pos.z;
		}
	}

	// Store the centre point of the minimum and maximumn X, Y and Z values
	// in BoundingSphereCentre:
	BoundingSphereCentre.x = (MaximumXYZValues.x - abs(MinimumXYZValues.x)) / 2.0f;
	BoundingSphereCentre.y = (MaximumXYZValues.y - abs(MinimumXYZValues.y)) / 2.0f;
	BoundingSphereCentre.z = (MaximumXYZValues.z - abs(MinimumXYZValues.z)) / 2.0f;
}

// Find the radius of the sphere cast from the object's centre point,
// to the furthest out vertex:
void GameObject::CalculateBoundingSphereRadius()
{
	float GreatestDistance = 0.0f;

	for (UINT VerticesIterator = 0u; VerticesIterator <
		ObjectModelReference->numverts; VerticesIterator++)
	{
		float CurrentDistance = CalculateCentreToVertexDistanceSquared(
			VerticesIterator);

		if (CurrentDistance > GreatestDistance)
		{
			GreatestDistance = CurrentDistance;
		}
	}

	BoundingSphereRadius = GreatestDistance;
}

// To help in calculating the distance between the centre point
// and a particular vertex:
float GameObject::CalculateCentreToVertexDistanceSquared(int VertexIndex)
{
	return (pow(BoundingSphereCentre.x - ObjectModelReference->
		vertices[VertexIndex].Pos.x, 2) + pow(BoundingSphereCentre.y -
		ObjectModelReference->vertices[VertexIndex].Pos.y, 2)
		+ pow(BoundingSphereCentre.z - ObjectModelReference->
			vertices[VertexIndex].Pos.z, 2));
}

// Initialise all shaders:
HRESULT GameObject::InitialiseShaders(HRESULT& ResultHandleReference)
{
	// 'Load and compile pixel and vertex shaders - use vs_5_0 to target DX11 hardware only'
	ID3DBlob *VertexShaderBlob, *PixelShaderBlob, *Error;
	ResultHandleReference = D3DX11CompileFromFile("Model_Shaders.hlsl", 0, 0, "ModelVS", "vs_4_0", 0, 0, 0,
		&VertexShaderBlob, &Error, 0);

	if (Error != 0) // 'check for shader compilation error'
	{
		OutputDebugStringA((char*)Error->GetBufferPointer());
		Error->Release();
		if (FAILED(ResultHandleReference)) // 'don't fail is error is just a warning'
		{
			return ResultHandleReference;
		};
	}

	ResultHandleReference = D3DX11CompileFromFile("Model_Shaders.hlsl", 0, 0, "ModelPS", "ps_4_0", 0, 0, 0,
		&PixelShaderBlob, &Error, 0);

	if (Error != 0) // 'check for shader compilation error'
	{
		OutputDebugStringA((char*)Error->GetBufferPointer());
		Error->Release();
		if (FAILED(ResultHandleReference)) // 'don't fail is error is just a warning'
		{
			return ResultHandleReference;
		};
	}

	// 'Create shader objects'
	ResultHandleReference = D3DDeviceReference->CreateVertexShader(VertexShaderBlob->GetBufferPointer(),
		VertexShaderBlob->GetBufferSize(), NULL, &GameObjectVertexShaderReference);

	if (FAILED(ResultHandleReference))
	{
		return ResultHandleReference;
	}

	ResultHandleReference = D3DDeviceReference->CreatePixelShader(PixelShaderBlob->GetBufferPointer(),
		PixelShaderBlob->GetBufferSize(), NULL, &GameObjectPixelShaderReference);

	if (FAILED(ResultHandleReference))
	{
		return ResultHandleReference;
	}

	// 'Set the shader objects as active'
	ImmediateContextReference->VSSetShader(GameObjectVertexShaderReference, nullptr, 0);
	ImmediateContextReference->PSSetShader(GameObjectPixelShaderReference, nullptr, 0);

	// 'Create and set the input layout object'
	D3D11_INPUT_ELEMENT_DESC iedesc[] =
	{
		{ "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0, D3D11_INPUT_PER_VERTEX_DATA, 0 },
		{ "COLOR", 0, DXGI_FORMAT_R32G32B32A32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
		{ "TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
		{ "NORMAL", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 }
	};

	ResultHandleReference = D3DDeviceReference->CreateInputLayout(iedesc, ARRAYSIZE(iedesc), VertexShaderBlob->GetBufferPointer(),
		VertexShaderBlob->GetBufferSize(), &GameObjectInputLayoutReference);

	if (FAILED(ResultHandleReference))
	{
		return ResultHandleReference;
	}

	ImmediateContextReference->IASetInputLayout(GameObjectInputLayoutReference);

	return ResultHandleReference;
}

// Initialise all constant buffer(s):
HRESULT GameObject::InitialiseConstantBuffers(HRESULT & ResultHandleReference)
{
	D3D11_BUFFER_DESC ModelConstantBufferDescription;
	ZeroMemory(&ModelConstantBufferDescription, sizeof(ModelConstantBufferDescription));
	ModelConstantBufferDescription.Usage = D3D11_USAGE_DEFAULT; // 'Can use UpdateSubresource() to update'
	ModelConstantBufferDescription.ByteWidth = FIRST_CONSTANT_BUFFER_BYTE_WIDTH; // 'MUST be a multiple of 16, calculate from CB struct'
	ModelConstantBufferDescription.BindFlags = D3D11_BIND_CONSTANT_BUFFER; // 'Use as a constant buffer'
	ResultHandleReference = D3DDeviceReference->CreateBuffer(&ModelConstantBufferDescription, nullptr,
		&GameObjectConstantBufferReference);

	return ResultHandleReference;
}

// Load an object:
int GameObject::LoadObjectModel(std::string FileName)
{
	// C-Style cast from const char* to char* used here (from std::string): 
	if (!ObjectModelReference)
	{
		ObjectModelReference = new ObjFileModel((char*)FileName.c_str(), D3DDeviceReference,
			ImmediateContextReference);
	}
	
	if (ObjectModelReference->filename == FILE_NOT_LOADED)
	{
		return S_FALSE;
	}

	// The centre point can now be calculated for this model:
	CalculateModelCentrePoint();
	CalculateBoundingSphereRadius();

	return S_OK;
}

bool GameObject::ObjectModelFileReferenceValid()
{
	bool ReferenceValid = false;

	if (ObjectModelReference)
	{
		ReferenceValid = true;
	}

	return ReferenceValid;
}

// To draw this model:
void GameObject::Draw(XMMATRIX* View, XMMATRIX* Projection)
{
	// Scale first, then rotation, with translation as the last of 
	// the transformation actions to take place:
	World = XMMatrixScalingFromVector(ObjectScaleVector);

	// Get the rotation values in radians first though:
	float PitchRotationRadians = XMConvertToRadians(RotationVector.x);
	float YawRotationRadians = XMConvertToRadians(RotationVector.y);
	float RollRotationRadians = XMConvertToRadians(RotationVector.z);

	World *= XMMatrixRotationRollPitchYaw(PitchRotationRadians, 
		YawRotationRadians, RollRotationRadians);
	World *= XMMatrixTranslationFromVector(PositionVector);

	// For lighting on this object:
	XMMATRIX TransposeMatrix = XMMATRIX();
	MODEL_CONSTANT_BUFFER ObjectConstantBufferValues;
	ObjectConstantBufferValues.WorldViewProjectionMatrix = World * (*View) * (*Projection);
	
	ObjectConstantBufferValues.DirectionalLightColour = DirectionalLightColour;
	ObjectConstantBufferValues.AmbientLightColour = AmbientLightColour;
	ObjectConstantBufferValues.DirectionalLightVector = XMVector3Transform(DirectionalLightShinesFrom,
		TransposeMatrix);
	ObjectConstantBufferValues.DirectionalLightVector = XMVector3Normalize(ObjectConstantBufferValues.
		DirectionalLightVector);

	ImmediateContextReference->VSSetConstantBuffers(0u, 1u, &GameObjectConstantBufferReference);
	ImmediateContextReference->UpdateSubresource(GameObjectConstantBufferReference, 0u, nullptr,
		&ObjectConstantBufferValues, 0u, 0u);

	// Set this model's shaders and input layout as active:
	ImmediateContextReference->VSSetShader(GameObjectVertexShaderReference, nullptr, 0);
	ImmediateContextReference->PSSetShader(GameObjectPixelShaderReference, nullptr, 0);
	ImmediateContextReference->IASetInputLayout(GameObjectInputLayoutReference);

	// Make sure this is valid before using it:
	if (ObjectModelReference)
	{
		ObjectModelReference->Draw();
	}	
}

void GameObject::SetPositionVector(XMVECTOR NewPosition)
{
	PositionVector = NewPosition;
}

// Get Functions:

// For collision detection:
XMVECTOR GameObject::GetBoundingSphereWorldSpacePosition()
{
	XMMATRIX WorldSphere = XMMATRIX();

	WorldSphere = XMMatrixScalingFromVector(ObjectScaleVector);
	
	// Get the rotation values in radians first though:
	float PitchRotationRadians = XMConvertToRadians(RotationVector.x);
	float YawRotationRadians = XMConvertToRadians(RotationVector.y);
	float RollRotationRadians = XMConvertToRadians(RotationVector.z);

	WorldSphere *= XMMatrixRotationRollPitchYaw(PitchRotationRadians,
		YawRotationRadians, RollRotationRadians);

	WorldSphere *= XMMatrixTranslationFromVector(PositionVector);

	XMVECTOR Offset = XMVectorSet(BoundingSphereCentre.x, BoundingSphereCentre.y,
		BoundingSphereCentre.z, 0.0f);
	Offset = XMVector3Transform(Offset, WorldSphere);
	return Offset;
}

bool GameObject::CheckCollision(GameObject*& TargetObject)
{
	if (TargetObject == this)
	{
		return false;
	}

	XMVECTOR ThisGameObjectBoundingSphereWorldSpacePosition =
		GetBoundingSphereWorldSpacePosition();
	XMVECTOR TargetObjectBoundingSphereWorldSpacePosition =
		TargetObject->GetBoundingSphereWorldSpacePosition();

	float DistanceBetweenWorldSpacePositionsSquared =
		CalculateDistanceSquaredBetweenBoundingSpheres(
			ThisGameObjectBoundingSphereWorldSpacePosition,
			TargetObjectBoundingSphereWorldSpacePosition);
	float BoundingSphereRadiiSum = GetBoundingSphereRadius() +
		TargetObject->GetBoundingSphereRadius();
	
	bool Collision = DistanceBetweenWorldSpacePositionsSquared <=
		BoundingSphereRadiiSum;

	return DistanceBetweenWorldSpacePositionsSquared <=
		BoundingSphereRadiiSum;
}

// Find the square distance between this object's bounding-sphere's
// centre point and TargetVector:
float GameObject::CalculateDistanceSquaredBetweenBoundingSpheres(
	XMVECTOR ThisGameObjectBoundingSphereWorldSpacePosition,
	XMVECTOR TargetBoundingSphereWorldSpacePosition)
{
	return pow(ThisGameObjectBoundingSphereWorldSpacePosition.x -
		TargetBoundingSphereWorldSpacePosition.x, 2) +
		pow(ThisGameObjectBoundingSphereWorldSpacePosition.y -
			TargetBoundingSphereWorldSpacePosition.y, 2) +
		pow(ThisGameObjectBoundingSphereWorldSpacePosition.z -
			TargetBoundingSphereWorldSpacePosition.z, 2);
}

void GameObject::Yaw(float RotationValue)
{
	RotationVector.y += RotationValue;
	MaintainYawRange();
}

void GameObject::Pitch(float RotationValue)
{
	RotationVector.x += RotationValue;
	MaintainPitchRange();
}

void GameObject::MaintainPitchRange()
{
	// Keep this rotation value in the -90 to 90 range;
	if (RotationVector.x > MAXIMUM_PITCH)
	{
		RotationVector.x = MAXIMUM_PITCH;
	}

	if (RotationVector.x < MINIMUM_PITCH)
	{
		RotationVector.x = MINIMUM_PITCH;
	}
}

void GameObject::MaintainYawRange()
{
	// Keep this rotation value in the 0 to 360 range:
	if (RotationVector.y > MAXIMUM_YAW)
	{
		RotationVector.y -= MAXIMUM_YAW;
	}

	if (RotationVector.y < MINIMUM_YAW)
	{
		RotationVector.y += MAXIMUM_YAW;
	}
}

// Get functions:

float GameObject::GetBoundingSphereRadius()
{
	// One can use x, y or z for this calculation:
	return BoundingSphereRadius * ObjectScaleVector.x;
}

float GameObject::GetScale()
{
	return GameObjectScale;
}

XMVECTOR& GameObject::GetVectorPosition()
{
	return PositionVector;
}

XMFLOAT3& GameObject::GetPositionFloat3()
{
	return PositionFloat3;
}

XMVECTOR& GameObject::GetVectorRotation()
{
	return RotationVector;
}

XMMATRIX& GameObject::GetRotationMatrix()
{
	return RotationMatrix;
}

std::string& GameObject::GetObjectModelFileName()
{
	return ObjectModelReference->filename;
}

XMVECTOR& GameObject::GetDirectionalLightShinesFrom()
{
	return DirectionalLightShinesFrom;
}

XMVECTOR& GameObject::GetDirectionalLightColour()
{
	return DirectionalLightColour;
}

XMVECTOR& GameObject::GetAmbientLightColour()
{
	return AmbientLightColour;
}
