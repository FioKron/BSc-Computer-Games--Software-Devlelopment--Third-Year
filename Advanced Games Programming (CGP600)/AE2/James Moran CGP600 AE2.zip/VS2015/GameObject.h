#pragma once
#include "objfilemodel.h"

/**
	This class is used to wrap objfilemodel.h's
	functionality, in a format that one can
	use to load .obj files into the project.

	This is to be used for all objects that are
	visible to the Player in the level (scene),
	such as their tank, enemy tanks and objects
	they can interact with (such as Energy-
	Capsules).
*/

class GameObject
{

protected:

	// Functions:

	/** Get the centre point of this GameObject's model. */
	void CalculateModelCentrePoint();

	/** Get the radius of this bounding sphere. */
	void CalculateBoundingSphereRadius();
	float CalculateCentreToVertexDistanceSquared(int VertexIndex);

	// Properties:

	/** Reference pointers. */
	ID3D11Device* D3DDeviceReference;
	ID3D11DeviceContext* ImmediateContextReference;

	ObjFileModel* ObjectModelReference;
	ID3D11VertexShader* GameObjectVertexShaderReference;
	ID3D11PixelShader* GameObjectPixelShaderReference;
	ID3D11InputLayout* GameObjectInputLayoutReference;
	ID3D11Buffer* GameObjectConstantBufferReference;

	/** For transformation of this object. */

	float GameObjectScale;
	XMVECTOR ObjectScaleVector;

	XMVECTOR UpDirectionVector;
	XMVECTOR PositionVector;
	/** 
		For the PlayerHoverTank to parse
		this value to the Camera class.
	*/
	XMFLOAT3 PositionFloat3;
	XMVECTOR RotationVector;

	XMMATRIX RotationMatrix;
	XMMATRIX World;

	/** For basic bounding-sphere collision. */
	XMFLOAT3 BoundingSphereCentre;
	float BoundingSphereRadius;

	/** For the lighting this object. */
	XMVECTOR DirectionalLightShinesFrom;
	XMVECTOR DirectionalLightColour;
	XMVECTOR AmbientLightColour;

	// Constant values:

	/**
		To use instead of having to type
		out "FILE NOT LOADED".
	*/
	const std::string FILE_NOT_LOADED = "FILE NOT LOADED";

	const UINT FIRST_CONSTANT_BUFFER_BYTE_WIDTH = 112u;

	// Functions:

	/** For initialising the shaders */
	HRESULT InitialiseShaders(HRESULT& ResultHandleReference);

	/** For initialising the constant-buffer(s) */
	HRESULT InitialiseConstantBuffers(HRESULT& ResultHandleReference);

	/** Keep rotation values within certain bounds */
	void MaintainPitchRange();
	void MaintainYawRange();

public:

	// Functions:

	/** Standard constructor. */
	 GameObject(ID3D11Device*& NewD3DDeviceReference, ID3D11DeviceContext*&
		NewD3DDeviceContextReference, HRESULT& ResultHandleReference,
		XMFLOAT3& InitialPosition);

	/** 
		Standard destructor (can be overriden by
		sub-classes). 
	*/
	virtual ~GameObject();

	/** Load a model .obj. */
	int LoadObjectModel(std::string FileName);

	/** Check to see if this is valid. */
	bool ObjectModelFileReferenceValid();

	/** 
		To draw the .obj model (can be overriden if 
		additional processing is required). 
	*/
	virtual void Draw(XMMATRIX* View, XMMATRIX* Projection);

	// Set methods:

	/** For if a collision occurs. */
	void SetPositionVector(XMVECTOR NewPosition);

	/** For rotation */
	void Yaw(float RotationValue);
	void Pitch(float RotationValue);

	// Get functions:

	/** 
		Get the world space coordinates of the 
		bounding sphere's centre point. 
	*/
	XMVECTOR GetBoundingSphereWorldSpacePosition();

	/** Check against another GameObject for collision. */
	bool CheckCollision(GameObject*& TargetObject);
	float CalculateDistanceSquaredBetweenBoundingSpheres(XMVECTOR
		ThisGameObjectBoundingSphereWorldSpacePosition, XMVECTOR
		TargetBoundingSphereWorldSpacePosition);

	float GetBoundingSphereRadius();

	float GetScale();

	/** For getting the position and rotation. */
	XMVECTOR& GetVectorPosition();
	XMFLOAT3& GetPositionFloat3();
	XMVECTOR& GetVectorRotation();
	XMMATRIX& GetRotationMatrix();

	/** Get the file path of the object model */
	std::string& GetObjectModelFileName();

	XMVECTOR& GetDirectionalLightShinesFrom();
	XMVECTOR& GetDirectionalLightColour();
	XMVECTOR& GetAmbientLightColour();

	// Properties:

	// Constant values:

	const XMFLOAT3 ZERO_FLOAT3 = XMFLOAT3(0.0f, 0.0f, 0.0f);

	const float MINIMUM_PITCH = -90.0f;
	const float MAXIMUM_PITCH = 90.0f;
	const float MINIMUM_YAW = 0.0f;
	const float MAXIMUM_YAW = 360.0f;
};