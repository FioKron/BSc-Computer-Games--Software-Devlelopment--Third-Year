#pragma once
#include "GameObject.h"
class StaticObstacle : public GameObject
{

public:

	// Functions/methods:

	/** Standard constructor */
	StaticObstacle(ID3D11Device*& NewD3DDeviceReference, ID3D11DeviceContext*&
		NewD3DDeviceContextReference, HRESULT& ResultHandleReference,
		XMFLOAT3& InitialPosition);

	/** Standard destructor */
	~StaticObstacle();

	// Properties:

	// Constant values:

	const float REPULSION_FORCE_MAGNITUDE = 10.0f;
};

