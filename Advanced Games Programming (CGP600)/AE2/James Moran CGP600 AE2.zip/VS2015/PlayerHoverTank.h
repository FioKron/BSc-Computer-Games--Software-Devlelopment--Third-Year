#pragma once

/**
	This class is used to represent the Player
	(so not only a GameObject, but this class 
	uses a Camera as well).
*/

#include "ControlledObject.h"
#include "Camera.h"

class PlayerHoverTank : public ControlledObject
{

private:

	// Properties:

	/** This Camera will follow the Player around */
	Camera* PlayerCamera;

	/** For refering to the result-handle. */
	HRESULT PlayerResultHandleReference;

	/** Their important statistics. */
	int CurrentHealth;
	int EnergyCapsulesCollected;
	
	// Flags:

	bool PlayerIsAlive;
	bool PlayerHasWon;

public:

	// Functions:

	/** Standard constructor. */
	PlayerHoverTank(ID3D11Device*& NewD3DDeviceReference, ID3D11DeviceContext*&
		NewD3DDeviceContextReference, HRESULT& ResultHandleReference,
		XMFLOAT3& InitialPosition);

	/** Standard destructor. */
	~PlayerHoverTank();	

	// Get Functions:

	Camera*& GetPlayerCameraReference();
	bool GetPlayerHasWon();
	bool GetPlayerIsAlive();

	/**
		For the Player's hover-tank to handle camera positioning 
		relative to the tank.
	*/
	void Draw(XMMATRIX* View, XMMATRIX* Projection)override;

	/** 
		Handle damage/healing to the Player's hover-tank
		(parse in a positive value to damage them, or a 
		negative value to heal them).
	*/
	void ModifyHealth(int HealthModificationValue);

	/** For when they collect a capsule. */
	void CapsuleCollected();

	// Properties:

	const XMVECTOR DEFAULT_CAMERA_LOCATION = XMVectorSet(0.0f, 30.0f, 30.0f, 0.0f);
	const XMVECTOR DEFAULT_CAMERA_ORIENTATION = XMVectorSet(45.0f, 180.0f, 0.0f, 0.0f);
	/** For use in repelling EnemyHoverTanks. */
	const float REPULSION_FORCE_MAGNITUDE = 100.0f;

	const int DEFAULT_INITIAL_HEALTH = 100;
	const int GOAL_CAPSULE_COUNT = 20;
};