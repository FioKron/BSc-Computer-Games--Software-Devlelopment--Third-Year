I have tested this application's release version on this my own desktop PC
(running Windows 10 Education, a netbook a take around with me (running
Windows 8 Home) and on my Fathers laptop (running Windows Vista).
The game runs fine on all of these platforms without any discernable
issues.


SEARCH AND COLLECT

The Player can win and lose at the game, but there is no HUD or any 
indication that they have won other than:

When the Player wins, the application is terminated within 3 seconds
of them picking up the last Energy Capsule.

When the Player loses, their hover-tank's mesh vanishes, with them
able to see the empty space where their hover-tank was, for 3 seconds.

CONTROLS:

W: Move forwards.
A: Move leftwards.
S: Move backwards.
D: Move rightwards.
Q: Yaw leftwards.
E: Yaw rightwards.

In the default level, the first row of objects are the Energy-Capsules,
that the Player has to collect all of to win the game.

The second row of objects are moveable-obstacles (when the Player's 
hover-tank/Enemy hover-tanks collide with these, they will move as
per the controlled object's velocity-direction (but at a fixed rate)).

The third row of objects are static-obstacles (when the Player's 
hover-tank/Enemy hover-tanks collide with these, they will not be able
to traverse through 